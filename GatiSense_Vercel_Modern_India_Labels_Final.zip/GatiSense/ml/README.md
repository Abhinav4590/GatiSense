# ml/ — future ETA prediction model

This folder is intentionally empty in the prototype.

When the real ML pipeline is built, it goes here, structured roughly as:

```
ml/
├── data/            → raw + processed historical train-running data
├── preprocessing/     → cleaning, feature engineering
├── training/           → model training scripts
├── prediction/           → inference code called by the backend
└── model/                 → saved/trained model files
```

## The core idea (see eta.js for how this is currently simulated)

```
Predicted ETA = Scheduled Arrival + Predicted Delay
```

The model's only real job is predicting **delay in minutes**, not a clock
time directly — that's why `js/data.js` stores `predictedDelayMin`
separately from `scheduledArrival` and adds them together.

**Suggested input features:**
train number, station, route position, distance remaining, scheduled
arrival/departure, current delay, previous-station delay, historical
average delay on this route, day of week, hour, train type, average
speed, stops remaining.

**Suggested starting point:** Linear Regression as a baseline, then compare
against Random Forest / Gradient Boosting / XGBoost. Evaluate with MAE and
RMSE — MAE is the easier one to explain in a presentation ("on average,
the prediction was off by X minutes").

**Data honesty rule carried over from the frontend:** if historical
Indian Railways data isn't available, use a clearly labeled simulated
dataset for training — never present simulated data as real live
telemetry, in the model docs or the UI.
