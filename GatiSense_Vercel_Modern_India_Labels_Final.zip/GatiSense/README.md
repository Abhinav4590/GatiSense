# GatiSense — AI-Powered Dynamic Train ETA & Delay Prediction

**Track. Predict. Travel Smarter.**

A passenger-facing prototype: search a train, see where it is, see how
late it is, see an AI-predicted arrival that updates as new running
information comes in, save trains, and set alerts.

## How to run it

No build step, no server required for most pages — open `index.html`
directly in a browser. **Live Tracking and Railway Map load real map
tiles over the internet**, so for those two, use a local server (in VS
Code: install the "Live Server" extension → right-click `index.html` →
"Open with Live Server") and you'll need an internet connection for the
map tiles to actually appear.

## Full page list

| Page | File | Requires login? |
|---|---|---|
| Home | `index.html` | No |
| Search Train | `search.html` | No |
| Live Tracking | `tracking.html` | No — saving a train does |
| ETA Prediction | `eta.html` | No |
| Live Station | `station.html` | No |
| Railway Map | `map.html` | No |
| Alerts | `alerts.html` | No (stored per-device) |
| Login | `login.html` | — |
| Signup | `signup.html` | — |
| My Trains | `my-trains.html` | Yes |
| Notifications | `notifications.html` | Yes |

The train catalogue now contains **27 real Indian Railways services** with real train numbers, names and published source/destination routes. The expanded set includes Rajdhani, Shatabdi, Sampark Kranti, Superfast and other long-distance services. The identity and route information is based on published Indian Railways/CRIS train lists; the live position and ETA values in this prototype remain simulated until an authorized live running-status feed is connected.

Try `search.html?q=12951` for the Mumbai Rajdhani, or search any of the other 26 train numbers/names. Every supported train has an independently updating ETA and route view.

## The Railway Map, in detail

- **Every major Indian station is in the database** (`STATION_COORDS`
  in `js/data.js`) — not just stations a demo train happens to visit.
  Search any of them by name in the search box (live autocomplete).
- **Real railway geometry from OpenStreetMap**: GatiSense uses the
  Esri-hosted OSM Railway Network polyline service together with the
  existing Indian railway GIS layer. This preserves broad OSM railway
  coverage without baking station symbols into raster tiles.
- **Free zoom and pan**, mouse-wheel included, same as you'd expect
  from Google Maps — it's not locked to one route's bounding box.
- A light dashed-line "network overview" connects major hubs for a
  big-picture read at low zoom; it is schematic, not the source of
  the railway geometry. Station symbols are rendered only by
  GatiSense from fixed geographic coordinates.

## Auth, saved trains, alerts — how the state works

- `GatiAuth` (in `js/global.js`) simulates login with `localStorage`,
  so it persists as you move between the separate HTML pages.
- `GatiSaved` (also in `js/global.js`) is the single shared place that
  reads/writes saved trains — used by the Save button on Tracking, and
  by My Trains and Notifications, so there's one copy of this logic,
  not three.
- Alerts and destination alerts are stored locally per the project's
  prototype rule (see `js/alerts.js`) — no login required to set them
  up on this device.
- Notifications aren't hardcoded text — `js/notifications.js` builds
  them from each saved train's *actual* current delay and ETA history,
  so what you see there always matches Tracking and ETA Prediction for
  the same train.

## Project structure

```
GatiSense/
├── index.html, search.html, tracking.html, eta.html, station.html,
│   map.html, alerts.html, login.html, signup.html, my-trains.html,
│   notifications.html
├── css/
│   ├── global.css      → shared design system
│   └── <page>.css       → one file per page
├── js/
│   ├── global.js         → mobile menu, GatiAuth, GatiSaved, toast
│   ├── data.js             → ⭐ centralized demo data — single source of truth
│   └── <page>.js            → one file per page (auth.js is shared by login+signup)
├── assets/
│   ├── logo/ , images/       → the GatiSense logo and hero photo
│   └── icons/                  → empty — all current icons are inline SVG
├── backend/    → empty — see backend/README.md for the planned FastAPI structure
└── ml/          → empty — see ml/README.md for the planned prediction model
```

## The core ETA concept, in code

```js
Predicted ETA = Scheduled Arrival + Predicted Delay (minutes)
```

`js/data.js` stores `eta.scheduledArrival` and `eta.predictedDelayMin`
separately (not just a final clock time) so the model's real job stays
narrow: predict a number of minutes, not a whole arrival time from
scratch. See `ml/README.md` for how this becomes a real model later.

## Design rules this build follows

- Orange is an accent, not the whole website — most surfaces stay white/light-grey
- No invented delay reasons ("signal failure" etc.) — only data-supported factors (current delay, previous-station delay, historical pattern, expected recovery)
- No ML jargon in the UI — "AI Predicted Arrival" and "Expected Delay," never "residual" or "model output"
- Confidence shown as **High / Moderate**, not a raw percentage
- Train numbers/names/routes are real published railway data; simulated position, delay and ETA are explicitly labeled so they are never mistaken for live Indian Railways telemetry
- Basic tracking, search, ETA and station info never require login — only personalization (My Trains, Notifications) does
