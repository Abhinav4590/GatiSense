# backend/ — future FastAPI backend

This folder is intentionally empty in the prototype.

When the real backend is built, it goes here, structured roughly as:

```
backend/
├── main.py
├── routes/          → API endpoints (trains, stations, auth, alerts)
├── services/         → business logic (status lookup, ETA orchestration)
├── models/            → Pydantic/DB models
├── database/           → MySQL connection + queries
└── authentication/      → signup/login, password hashing, sessions
```

## How the frontend will connect to it

Right now every page reads demo data from `js/data.js` — functions like
`getTrain()`, `searchTrains()` and `getStationArrivals()`.

To go live, those functions get rewritten to call the backend instead of
reading the local arrays, e.g.:

```js
// Before (prototype):
function getTrain(number){
  return GATI_TRAINS.find(t => t.number === number);
}

// After (real backend):
async function getTrain(number){
  const res = await fetch('/api/trains/' + number + '/status');
  return res.json();
}
```

Because every page already calls these functions instead of touching the
data arrays directly, no HTML or page-specific JS needs to change — only
`js/data.js`.

Suggested endpoints (see the main README for the full list):

```
GET  /api/trains
GET  /api/trains/{number}
GET  /api/trains/{number}/status
GET  /api/trains/{number}/eta
GET  /api/stations/{code}/trains
POST /api/auth/signup
POST /api/auth/login
GET  /api/my-trains
POST /api/my-trains
DELETE /api/my-trains/{number}
GET  /api/alerts
POST /api/alerts
```
