/* ==========================================================
   GATISENSE — VERIFIED ALL-INDIA STATION DIRECTORY
   Primary directory: dataset mirrored from Indian Railways' official
   Station_Name_8477 station list. Current-name corrections below are
   applied where later official railway/government material confirms a
   rename. Search logic is city-aware: an exact city query does not pull
   unrelated station names that merely contain the same characters.
   ========================================================== */

var GATI_STATION_DIRECTORY_URL = 'https://raw.githubusercontent.com/namastevis/All-Railway-Stations/master/stations.json';
var GATI_OFFICIAL_STATION_SOURCE = 'https://indianrailways.gov.in/railwayboard/uploads/directorate/traffic_comm/Station_Name_8477.pdf';
var GATI_STATION_DIRECTORY = [];
var GATI_STATION_DIRECTORY_READY = false;
var GATI_STATION_DIRECTORY_LOADING = null;

function stationText(value){
  return String(value || '').toLowerCase().replace(/[.']/g,'').replace(/\s+/g,' ').trim();
}

/* Current-use corrections / legacy records that must not appear as a
   separate station. Keep old names as search aliases, not live stations. */
var GATI_STATION_CORRECTIONS = {
  hideCodes: {
    'fd': true // Faizabad Jn is the old name/code record for Ayodhya Cantt.
  },
  overrides: {
    'ay': { name:'Ayodhya Dham Junction', city:'Ayodhya', state:'Uttar Pradesh', zone:'NR', aliases:['Ayodhya','Ayodhya Dham','Faizabad'] },
    'ayc': { name:'Ayodhya Cantt', city:'Ayodhya', state:'Uttar Pradesh', zone:'NR', aliases:['Ayodhya Cantt','Faizabad Cantt','Faizabad'] }
  },
  cityAliases: {
    'ayodhya':['ayodhya','faizabad'],
    'prayagraj':['prayagraj','allahabad'],
    'mumbai':['mumbai','bombay'],
    'bengaluru':['bengaluru','bangalore'],
    'kolkata':['kolkata','calcutta'],
    'chennai':['chennai','madras'],
    'gurugram':['gurugram','gurgaon'],
    'kochi':['kochi','cochin'],
    'thiruvananthapuram':['thiruvananthapuram','trivandrum'],
    'vadodara':['vadodara','baroda'],
    'varanasi':['varanasi','banaras','kashi'],
    'jamshedpur':['jamshedpur','tatanagar']
  }
};

function applyStationCorrection(station){
  var code = stationText(station.code);
  if(!code) return station;
  var override = GATI_STATION_CORRECTIONS.overrides[code];
  if(override){
    station.name = override.name;
    station.city = override.city;
    station.state = override.state;
    station.zone = override.zone;
    station.aliases = (override.aliases || []).slice();
  }
  return station;
}

function isHiddenStation(station){
  return !!GATI_STATION_CORRECTIONS.hideCodes[stationText(station.code)];
}

function buildFallbackStationDirectory(){
  var out = [];
  if(typeof STATION_COORDS === 'object'){
    Object.keys(STATION_COORDS).forEach(function(name){
      var coord = STATION_COORDS[name];
      out.push({code:'', name:name, city:name, state:'', zone:'', address:'', lat:coord[0], lon:coord[1]});
    });
  }

  /* Verified current Ayodhya city stations. Do NOT add Faizabad/FD as a
     third station: official NER material identifies Ayodhya Cantt as the
     old Faizabad station. */
  out.push(
    {code:'AY', name:'Ayodhya Dham Junction', city:'Ayodhya', state:'Uttar Pradesh', zone:'NR', address:'Ayodhya, Uttar Pradesh', lat:26.787784, lon:82.200604, aliases:['Ayodhya','Ayodhya Dham','Faizabad']},
    {code:'AYC', name:'Ayodhya Cantt', city:'Ayodhya', state:'Uttar Pradesh', zone:'NR', address:'Ayodhya, Uttar Pradesh', lat:26.76861, lon:82.13500, aliases:['Ayodhya Cantt','Faizabad Cantt','Faizabad']}
  );
  return dedupeStations(out.map(applyStationCorrection).filter(function(s){ return !isHiddenStation(s); }));
}

function normalizeDirectoryRows(rows){
  if(!Array.isArray(rows)) return [];
  return dedupeStations(rows.map(function(s){
    var c = s.coordinates || {};
    var station = {
      code: String(s.code || s.stnCode || '').trim(),
      name: String(s.name || s.stnName || '').trim(),
      city: String(s.city || s.stnCity || '').trim(),
      state: String(s.state || '').trim(),
      zone: String(s.zone || '').trim(),
      address: String(s.address || '').trim(),
      lat: Number(c.latitude != null ? c.latitude : s.lat),
      lon: Number(c.longitude != null ? c.longitude : (s.lon != null ? s.lon : s.long)),
      aliases: Array.isArray(s.aliases) ? s.aliases.slice() : []
    };
    return applyStationCorrection(station);
  }).filter(function(s){ return s.name && s.name.length > 1 && !isHiddenStation(s); }));
}

function dedupeStations(rows){
  var seen = {};
  return rows.filter(function(s){
    var key = stationText(s.code) + '|' + stationText(s.name) + '|' + stationText(s.city);
    if(seen[key]) return false;
    seen[key] = true;
    return true;
  });
}

function loadStationDirectory(){
  if(GATI_STATION_DIRECTORY_READY) return Promise.resolve(GATI_STATION_DIRECTORY);
  if(GATI_STATION_DIRECTORY_LOADING) return GATI_STATION_DIRECTORY_LOADING;

  GATI_STATION_DIRECTORY = buildFallbackStationDirectory();

  GATI_STATION_DIRECTORY_LOADING = fetch(GATI_STATION_DIRECTORY_URL, {cache:'no-store'})
    .then(function(r){
      if(!r.ok) throw new Error('Station directory request failed');
      return r.json();
    })
    .then(function(rows){
      var normalized = normalizeDirectoryRows(rows);
      if(normalized.length > 4000) GATI_STATION_DIRECTORY = normalized;
      GATI_STATION_DIRECTORY_READY = true;
      return GATI_STATION_DIRECTORY;
    })
    .catch(function(){
      GATI_STATION_DIRECTORY_READY = true;
      return GATI_STATION_DIRECTORY;
    });

  return GATI_STATION_DIRECTORY_LOADING;
}

function stationAliasesFor(s){
  var aliases = Array.isArray(s.aliases) ? s.aliases.slice() : [];
  aliases.push(s.name, s.code, s.city);
  return aliases.filter(Boolean).map(stationText);
}

function cityTermsForQuery(q){
  return GATI_STATION_CORRECTIONS.cityAliases[q] || [q];
}

/*
   Search rules:
   1. Exact station code/name wins.
   2. If the query exactly matches a city (including a known city alias),
      return stations belonging to that city only. This prevents results
      such as AYODHYAPATTANAM from appearing when the passenger typed
      AYODHYA.
   3. Otherwise search station name, code, city, aliases, state and address.
*/
function stationSearch(query, limit){
  var q = stationText(query);
  if(!q) return [];
  limit = limit || 100;

  var exactStation = GATI_STATION_DIRECTORY.filter(function(s){
    var aliases = stationAliasesFor(s);
    return aliases.indexOf(q) !== -1;
  });

  var terms = cityTermsForQuery(q);
  var exactCity = GATI_STATION_DIRECTORY.filter(function(s){
    var city = stationText(s.city);
    return terms.some(function(term){ return city === stationText(term); });
  });

  /* Exact city query: city membership is authoritative for the result set. */
  if(exactCity.length){
    var cityCodes = {};
    exactCity.forEach(function(s){ cityCodes[stationText(s.code)+'|'+stationText(s.name)] = true; });
    exactStation.forEach(function(s){ cityCodes[stationText(s.code)+'|'+stationText(s.name)] = true; });
    var cityResults = exactCity.concat(exactStation.filter(function(s){
      return !exactCity.some(function(c){ return stationText(c.code) === stationText(s.code); });
    }));
    cityResults.sort(function(a,b){
      var an = stationText(a.name), bn = stationText(b.name);
      var ac = stationText(a.code), bc = stationText(b.code);
      var as = ac === q ? 0 : an === q ? 1 : 2;
      var bs = bc === q ? 0 : bn === q ? 1 : 2;
      return as-bs || a.name.localeCompare(b.name);
    });
    return cityResults.slice(0, limit);
  }

  var results = GATI_STATION_DIRECTORY.filter(function(s){
    var name=stationText(s.name), code=stationText(s.code), city=stationText(s.city), state=stationText(s.state), address=stationText(s.address);
    var aliases = stationAliasesFor(s);
    return name.indexOf(q)!==-1 || code===q || code.indexOf(q)===0 || city.indexOf(q)!==-1 || state.indexOf(q)!==-1 || address.indexOf(q)!==-1 || aliases.some(function(a){ return a.indexOf(q)!==-1; });
  });

  results.sort(function(a,b){
    function score(s){
      var name=stationText(s.name), city=stationText(s.city), code=stationText(s.code);
      if(code===q) return 0;
      if(name===q) return 1;
      if(city===q) return 2;
      if(name.indexOf(q)===0) return 3;
      if(city.indexOf(q)===0) return 4;
      return 5;
    }
    var d=score(a)-score(b);
    return d || a.name.localeCompare(b.name);
  });
  return results.slice(0,limit);
}
