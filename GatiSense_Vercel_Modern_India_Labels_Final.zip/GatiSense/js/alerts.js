/* ==========================================================
   ALERTS PAGE JAVASCRIPT (alerts.html)
   Alert preferences are stored locally for this prototype. A
   real backend would replace localStorage here with
   POST /api/alerts and GET /api/alerts calls instead — the
   render/read functions below are written so that swap only
   touches this file.
   ========================================================== */

var ALERTS_KEY = 'gatisense_alerts';
var DEST_ALERTS_KEY = 'gatisense_destination_alerts';

function getAlerts(){ try{ return JSON.parse(localStorage.getItem(ALERTS_KEY)) || []; } catch(e){ return []; } }
function getDestAlerts(){ try{ return JSON.parse(localStorage.getItem(DEST_ALERTS_KEY)) || []; } catch(e){ return []; } }

var CONDITION_LABELS = {
  delay15: 'Delay over 15 min', etachange: 'ETA changes', approaching: 'Approaching station',
  cancelled: 'Cancellation', rescheduled: 'Rescheduling', diverted: 'Diversion'
};

// ==========================================
// POPULATE TRAIN SUGGESTIONS
// ==========================================
(function fillTrainOptions(){
  var list = document.getElementById('alert-train-options');
  list.innerHTML = GATI_TRAINS.map(function(t){
    return '<option value="' + t.number + '">' + t.number + ' ' + t.name + '</option>';
  }).join('');
})();

// ==========================================
// PERSONALIZED ALERT FORM
// ==========================================
document.getElementById('alert-form').addEventListener('submit', function(e){
  e.preventDefault();
  var trainNumber = document.getElementById('alert-train').value.trim();
  var mobile = document.getElementById('alert-mobile').value.trim();
  var train = getTrain(trainNumber);

  if(!train){ showToast('Enter a valid train number, e.g. 12951'); return; }

  var conditions = Array.from(document.querySelectorAll('input[name="cond"]:checked')).map(function(cb){ return cb.value; });
  var alerts = getAlerts().filter(function(a){ return a.trainNumber !== trainNumber; });
  alerts.push({ trainNumber: trainNumber, mobile: mobile, conditions: conditions });
  localStorage.setItem(ALERTS_KEY, JSON.stringify(alerts));

  showToast('SMS updates enabled for ' + trainNumber);
  e.target.reset();
  document.querySelectorAll('input[name="cond"]').forEach(function(cb){
    cb.checked = ['delay15','etachange','cancelled'].indexOf(cb.value) !== -1;
  });
  renderConfiguredAlerts();
});

// ==========================================
// DESTINATION ALERT FORM
// ==========================================
document.getElementById('destination-form').addEventListener('submit', function(e){
  e.preventDefault();
  var trainNumber = document.getElementById('dest-train').value.trim();
  var minutes = document.getElementById('dest-minutes').value;
  var train = getTrain(trainNumber);

  if(!train){ showToast('Enter a valid train number, e.g. 12951'); return; }

  var destAlerts = getDestAlerts().filter(function(a){ return a.trainNumber !== trainNumber; });
  destAlerts.push({ trainNumber: trainNumber, minutes: minutes });
  localStorage.setItem(DEST_ALERTS_KEY, JSON.stringify(destAlerts));

  showToast('Destination alert enabled for ' + trainNumber);
  e.target.reset();
  renderConfiguredAlerts();
});

// ==========================================
// RENDER CONFIGURED ALERTS
// ==========================================
function renderConfiguredAlerts(){
  var listEl = document.getElementById('configured-alerts-list');
  var alerts = getAlerts();
  var destAlerts = getDestAlerts();

  if(!alerts.length && !destAlerts.length){
    listEl.innerHTML = '<p class="alerts-empty-note">No alerts configured yet on this device.</p>';
    return;
  }

  var rows = [];

  alerts.forEach(function(a){
    var t = getTrain(a.trainNumber);
    var condText = a.conditions.map(function(c){ return CONDITION_LABELS[c]; }).join(', ') || 'No conditions selected';
    rows.push(
      '<div class="configured-alert-row">' +
        '<div><div class="name">' + a.trainNumber + (t ? (' ' + t.name) : '') + '</div><div class="detail">SMS alerts: ' + condText + (a.mobile ? (' · ' + a.mobile) : '') + '</div></div>' +
        '<button type="button" class="remove-btn" data-type="alert" data-num="' + a.trainNumber + '" aria-label="Remove"><svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px;"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
      '</div>'
    );
  });

  destAlerts.forEach(function(a){
    var t = getTrain(a.trainNumber);
    var when = a.minutes === '0' ? 'at arrival' : (a.minutes + ' min before arrival');
    rows.push(
      '<div class="configured-alert-row">' +
        '<div><div class="name">' + a.trainNumber + (t ? (' ' + t.name) : '') + '</div><div class="detail">Destination alert: ' + when + '</div></div>' +
        '<button type="button" class="remove-btn" data-type="dest" data-num="' + a.trainNumber + '" aria-label="Remove"><svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px;"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
      '</div>'
    );
  });

  listEl.innerHTML = rows.join('');

  listEl.querySelectorAll('.remove-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var num = btn.getAttribute('data-num');
      if(btn.getAttribute('data-type') === 'alert'){
        localStorage.setItem(ALERTS_KEY, JSON.stringify(getAlerts().filter(function(a){ return a.trainNumber !== num; })));
      } else {
        localStorage.setItem(DEST_ALERTS_KEY, JSON.stringify(getDestAlerts().filter(function(a){ return a.trainNumber !== num; })));
      }
      showToast('Alert removed');
      renderConfiguredAlerts();
    });
  });
}

renderConfiguredAlerts();
