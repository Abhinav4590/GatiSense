/* ==========================================================
   LOGIN / SIGNUP JAVASCRIPT (login.html, signup.html)
   Both pages share this file since the behavior is closely
   related. For this prototype, "authentication" is simulated
   with localStorage (see GatiAuth in global.js) — a real build
   would replace these two handlers with calls to
   POST /api/auth/login and POST /api/auth/signup instead.
   ========================================================== */

// ==========================================
// LOGIN
// ==========================================
var loginForm = document.getElementById('login-form');
if(loginForm){
  loginForm.addEventListener('submit', function(e){
    e.preventDefault();
    var id = document.getElementById('login-id').value.trim();
    var displayName = id.split('@')[0] || 'Guest';
    GatiAuth.login(displayName);
    showToast('Logged in as ' + displayName);
    setTimeout(function(){ window.location.href = 'my-trains.html'; }, 500);
  });

  document.getElementById('forgot-link').addEventListener('click', function(e){
    e.preventDefault();
    showToast('Password reset isn\'t wired up in this prototype yet.');
  });
}

// ==========================================
// SIGNUP
// ==========================================
var signupForm = document.getElementById('signup-form');
if(signupForm){
  signupForm.addEventListener('submit', function(e){
    e.preventDefault();
    var name = document.getElementById('signup-name').value.trim();
    var pass = document.getElementById('signup-pass').value;
    var confirm = document.getElementById('signup-confirm').value;
    var errorEl = document.getElementById('signup-error');

    if(pass !== confirm){
      errorEl.classList.remove('hidden');
      return;
    }
    errorEl.classList.add('hidden');

    GatiAuth.login(name || 'Guest');
    showToast('Account created — welcome, ' + (name || 'Guest') + '!');
    setTimeout(function(){ window.location.href = 'my-trains.html'; }, 500);
  });
}
