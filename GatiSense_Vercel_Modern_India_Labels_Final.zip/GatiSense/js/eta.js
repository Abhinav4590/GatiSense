/* ==========================================================
   ETA PREDICTION PAGE JAVASCRIPT (eta.html)
   ========================================================== */

var etaParams = new URLSearchParams(window.location.search);
var etaTrainNumber = etaParams.get('train') || '12951';
var etaTrain = getTrain(etaTrainNumber);

// The ETA page is train-selectable.  The selector is populated from the
// same centralized GATI_TRAINS catalogue used by Search and Live Tracking,
// so selecting a train never creates a second/inconsistent data source.
function populateEtaTrainSelector(activeNumber){
  var select = document.getElementById('eta-train-select');
  var count = document.getElementById('eta-train-count');
  var trigger = document.getElementById('eta-train-trigger');
  var triggerMain = document.getElementById('eta-train-trigger-main');
  var menu = document.getElementById('eta-train-menu');
  var search = document.getElementById('eta-train-search');
  var list = document.getElementById('eta-train-list');
  var empty = document.getElementById('eta-train-empty');
  var combobox = document.getElementById('eta-train-combobox');
  if(!select || !trigger || !menu || !list || typeof GATI_TRAINS === 'undefined') return;

  var trains = GATI_TRAINS.slice().sort(function(a, b){
    return String(a.number).localeCompare(String(b.number), undefined, {numeric:true});
  });
  var active = trains.find(function(t){ return t.number === activeNumber; }) || trains[0];

  select.innerHTML = '<option value="">Choose a train…</option>' + trains.map(function(t){
    var route = t.source + ' → ' + t.destination;
    return '<option value="' + t.number + '">' + escapeEtaHtml(t.number + ' · ' + t.name + ' — ' + route) + '</option>';
  }).join('');
  select.value = active ? active.number : '';

  count.textContent = trains.length + ' trains available · select a train to view its independent ETA prediction';

  function escapeEtaHtml(value){
    return String(value).replace(/[&<>"']/g, function(ch){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];
    });
  }

  function openMenu(){
    combobox.classList.add('open');
    trigger.setAttribute('aria-expanded','true');
    setTimeout(function(){ search.focus(); }, 0);
    renderList(search.value);
  }
  function closeMenu(){
    combobox.classList.remove('open');
    trigger.setAttribute('aria-expanded','false');
  }
  function chooseTrain(number){
    if(!number) return;
    select.value = number;
    var train = trains.find(function(t){ return t.number === number; });
    if(train){
      triggerMain.innerHTML = '<strong>' + escapeEtaHtml(train.number) + '</strong><span>' + escapeEtaHtml(train.name) + '</span><em>' + escapeEtaHtml(train.source) + ' → ' + escapeEtaHtml(train.destination) + '</em>';
    }
    var url = new URL(window.location.href);
    url.searchParams.set('train', number);
    window.location.href = url.toString();
  }
  function renderList(query){
    var q = String(query || '').trim().toLowerCase();
    var matches = trains.filter(function(t){
      var haystack = [t.number, t.name, t.source, t.destination, t.source + ' ' + t.destination].join(' ').toLowerCase();
      return !q || haystack.indexOf(q) !== -1;
    });
    list.innerHTML = matches.map(function(t){
      var selected = active && t.number === active.number;
      return '<button type="button" class="eta-train-option' + (selected ? ' selected' : '') + '" role="option" aria-selected="' + selected + '" data-train="' + escapeEtaHtml(t.number) + '">' +
        '<span class="eta-option-number">' + escapeEtaHtml(t.number) + '</span>' +
        '<span class="eta-option-content"><span class="eta-option-name">' + escapeEtaHtml(t.name) + '</span><span class="eta-option-route">' + escapeEtaHtml(t.source) + ' <b>→</b> ' + escapeEtaHtml(t.destination) + '</span></span>' +
        (selected ? '<span class="eta-option-check" aria-hidden="true">✓</span>' : '') +
      '</button>';
    }).join('');
    empty.classList.toggle('hidden', matches.length !== 0);
    Array.prototype.forEach.call(list.querySelectorAll('.eta-train-option'), function(btn){
      btn.addEventListener('click', function(){ chooseTrain(btn.getAttribute('data-train')); });
    });
  }

  triggerMain.innerHTML = active
    ? '<strong>' + escapeEtaHtml(active.number) + '</strong><span>' + escapeEtaHtml(active.name) + '</span><em>' + escapeEtaHtml(active.source) + ' → ' + escapeEtaHtml(active.destination) + '</em>'
    : 'Choose a train…';

  trigger.addEventListener('click', function(){
    if(combobox.classList.contains('open')) closeMenu(); else openMenu();
  });
  search.addEventListener('input', function(){ renderList(search.value); });
  search.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){ closeMenu(); trigger.focus(); }
  });
  document.addEventListener('click', function(e){
    if(!combobox.contains(e.target)) closeMenu();
  });
  trigger.addEventListener('keydown', function(e){
    if(e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' '){ e.preventDefault(); openMenu(); }
  });

  renderList('');
}
populateEtaTrainSelector(etaTrainNumber);

if(!etaTrain){
  document.getElementById('eta-content').classList.add('hidden');
  document.getElementById('eta-not-found').classList.remove('hidden');
} else {
  renderHeader(etaTrain);
  renderStatusBanner(etaTrain);
  renderInfobar(etaTrain);
  renderMainPrediction(etaTrain);

  if(etaTrain.dynamic || (etaTrain.stops && etaTrain.stops.length)){
    renderRouteTable(etaTrain);
  } else {
    renderHistory(etaTrain);
    renderPropagation(etaTrain);
  }
  renderForecastSidebar(etaTrain);

  renderFactors(etaTrain);
}

// Recalculate this train's prototype ETA independently every 30 seconds.
// The train number/name/route are real published data; the position and
// prediction are simulated until a live authorized running-status feed is connected.
setInterval(function(){
  if(!etaTrain) return;
  updateDynamicTrain(etaTrain);
  renderInfobar(etaTrain);
  renderMainPrediction(etaTrain);
  if(etaTrain.dynamic || (etaTrain.stops && etaTrain.stops.length)){
    renderRouteTable(etaTrain);
  } else {
    renderHistory(etaTrain);
    renderPropagation(etaTrain);
  }
  renderForecastSidebar(etaTrain);
  renderFactors(etaTrain);
}, 30000);

// ==========================================
// TIME HELPERS
// ==========================================
function timeToMinutes(hhmm){
  if(!hhmm) return null;
  var parts = hhmm.split(':');
  return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
}
function minutesDiff(schedStr, actualStr){
  var s = timeToMinutes(schedStr), a = timeToMinutes(actualStr);
  if(s === null || a === null) return 0;
  var diff = a - s;
  if(diff < -600) diff += 1440; // rolled past midnight
  return diff;
}
function addMinutes(hhmm, minutes){
  var total = timeToMinutes(hhmm);
  if(total === null) return null;
  total = (total + minutes + 1440) % 1440;
  var h = Math.floor(total / 60), m = total % 60;
  return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
}

// ==========================================
// HEADER — title, route, tags, status badge
// ==========================================
function renderHeader(t){
  document.title = t.number + ' ' + t.name + ' — ETA Prediction — GatiSense';
  document.getElementById('eta-title').textContent = t.number + ' ' + t.name;
  document.getElementById('eta-route').textContent = t.source + ' → ' + t.destination;

  var tags = (t.type || '').split('·').map(function(s){ return s.trim(); }).filter(Boolean);
  if(t.runningDays) tags.push(t.runningDays);
  document.getElementById('eta-tags').innerHTML = tags.map(function(tag){
    return '<span class="tag-chip">' + tag + '</span>';
  }).join('');

  var badge = document.getElementById('eta-status-badge');
  var isIssue = t.status === 'cancelled' || t.status === 'rescheduled' || t.status === 'diverted';
  if(isIssue){
    badge.className = 'badge badge-neutral';
    badge.textContent = statusWordLabel(t.status);
  } else {
    var status = delayStatusInfo(t.live.currentDelayMin);
    badge.className = 'badge ' + status.cls;
    badge.textContent = t.live.currentDelayMin > 0 ? ('Running · ' + status.label) : 'On time';
  }
}

// ==========================================
// STATUS BANNER — cancelled / rescheduled / diverted
// ==========================================
function renderStatusBanner(t){
  if(t.status !== 'cancelled' && t.status !== 'rescheduled' && t.status !== 'diverted') return;

  var banner = document.createElement('div');
  banner.className = 'status-banner ' + t.status;

  var iconPath = t.status === 'cancelled'
    ? '<path d="M6 6l12 12M18 6L6 18"/>'
    : '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>';

  var title = '', detail = '';
  if(t.status === 'cancelled'){
    title = 'Train Cancelled';
    detail = (t.statusDetail && t.statusDetail.note) || 'This service is cancelled — ETA prediction isn\'t applicable.';
  } else if(t.status === 'rescheduled'){
    title = 'Rescheduled';
    var sd = t.statusDetail || {};
    detail = 'Original departure ' + sd.originalDeparture + ' → now departing ' + sd.updatedDeparture + '.';
  } else if(t.status === 'diverted'){
    title = 'Running on a diverted route';
    detail = (t.statusDetail && t.statusDetail.note) || 'This train is currently on an alternate route.';
  }

  banner.innerHTML =
    '<div class="sb-icon"><svg class="icon" viewBox="0 0 24 24">' + iconPath + '</svg></div>' +
    '<div><h4>' + title + '</h4><p>' + detail + '</p></div>';

  document.querySelector('.tracking-head').insertAdjacentElement('afterend', banner);
}

// ==========================================
// INFO BAR — current station / next station / last updated
// ==========================================
function renderInfobar(t){
  document.getElementById('eta-current-station').textContent = t.live.currentLocationText || '—';
  document.getElementById('eta-next-station').textContent = t.live.nextStation
    ? (t.live.nextStation + (t.live.nextStationEta ? (' · ' + t.live.nextStationEta) : ''))
    : '—';
  document.getElementById('eta-updated').textContent = (t.live.lastUpdatedMinsAgo || 0) + ' min ago';
}

// ==========================================
// MAIN PREDICTION CARD
// ==========================================
function renderMainPrediction(t){
  document.getElementById('eta-scheduled').textContent = t.eta.scheduledArrival;
  document.getElementById('eta-scheduled-station').textContent = t.destination;
  document.getElementById('eta-predicted').textContent = t.eta.predictedArrival;
  document.getElementById('eta-predicted-station').textContent = t.destination;
  document.getElementById('eta-delay').textContent = t.eta.predictedDelayMin > 0 ? ('+' + t.eta.predictedDelayMin + ' min') : 'On time';

  var pct = t.eta.confidencePct || 0;
  document.getElementById('eta-confidence-pct').textContent = pct + '%';
  document.getElementById('eta-confidence-fill').style.width = pct + '%';
}

// ==========================================
// ROUTE-WISE ETA & DELAY FORECAST TABLE
// Only for trains with a full stop-by-stop schedule (12951 in
// this prototype). Departed stops use their real actual-vs-
// scheduled times; upcoming stops use the matching prediction
// from t.eta.propagation.
// ==========================================
function renderRouteTable(t){
  var card = document.getElementById('eta-route-table-card');
  var tbody = document.getElementById('eta-route-tbody');
  card.classList.remove('hidden');

  if(!t.stops || !t.stops.length){
    var route = getRoutePoints(t);
    var delay = t.eta.predictedDelayMin || 0;
    tbody.innerHTML = route.map(function(point, i){
      var isNext = point.name === t.live.nextStation;
      var statusLabel = i === 0 ? 'Origin' : (i === route.length - 1 ? 'Destination' : (isNext ? 'Next station' : 'Route checkpoint'));
      var statusCls = i === 0 ? 'badge-ontime' : (isNext ? 'badge-delayed' : 'badge-neutral');
      return '<tr>' +
        '<td>' + (i + 1) + '</td>' +
        '<td><span class="stn-cell"><span class="stn-dot ' + (isNext ? 'current' : '') + '"></span>' + point.name + '</span></td>' +
        '<td>—</td><td class="pred-cell">' + (isNext ? (t.live.nextStationEta || '—') : '—') + '</td>' +
        '<td>—</td><td class="pred-cell">—</td>' +
        '<td class="delay-cell" style="color:' + (delay > 0 ? 'var(--amber)' : 'var(--green)') + '">' + (delay ? ('+' + delay + ' min') : '—') + '</td>' +
        '<td><span class="badge ' + statusCls + '">' + statusLabel + '</span></td>' +
      '</tr>';
    }).join('');
    return;
  }

  tbody.innerHTML = t.stops.map(function(stop, i){
    var isDeparted = stop.state === 'departed';
    var isNext = stop.name === t.live.nextStation;
    var dotCls = isDeparted ? 'departed' : (isNext ? 'current' : '');
    var statusLabel = isDeparted ? GatiI18n.t('status.departed') : (isNext ? GatiI18n.t('status.current') : GatiI18n.t('status.upcoming'));
    var statusBadgeCls = isDeparted ? 'badge-ontime' : (isNext ? 'badge-delayed' : 'badge-neutral');

    var predArr, predDep, delayMin;

    if(isDeparted){
      predArr = stop.actualArr || stop.schedArr || '—';
      predDep = stop.actualDep || stop.schedDep || '—';
      delayMin = stop.schedArr ? minutesDiff(stop.schedArr, stop.actualArr) : (stop.schedDep ? minutesDiff(stop.schedDep, stop.actualDep) : 0);
    } else {
      var match = (t.eta.propagation || []).filter(function(p){ return p.station === stop.name; })[0];
      if(match){
        predArr = match.predicted;
        delayMin = match.delayMin;
      } else {
        predArr = stop.schedArr ? addMinutes(stop.schedArr, t.eta.predictedDelayMin) : '—';
        delayMin = t.eta.predictedDelayMin;
      }
      predDep = (stop.schedDep && stop.schedArr) ? addMinutes(predArr, timeToMinutes(stop.schedDep) - timeToMinutes(stop.schedArr)) : (stop.schedDep ? addMinutes(stop.schedDep, delayMin) : '—');
    }

    var sign = delayMin > 0 ? '+' : '';

    return (
      '<tr>' +
        '<td>' + (i + 1) + '</td>' +
        '<td><span class="stn-cell"><span class="stn-dot ' + dotCls + '"></span>' + stop.name + ' <span style="color:var(--ink-faint);font-weight:500;">(' + stop.code + ')</span></span></td>' +
        '<td>' + (stop.schedArr || '—') + '</td>' +
        '<td class="pred-cell">' + predArr + '</td>' +
        '<td>' + (stop.schedDep || '—') + '</td>' +
        '<td class="pred-cell">' + predDep + '</td>' +
        '<td class="delay-cell" style="color:' + (delayMin > 0 ? 'var(--amber)' : 'var(--green)') + ';">' + (delayMin === 0 ? '—' : sign + delayMin + ' min') + '</td>' +
        '<td><span class="badge ' + statusBadgeCls + '">' + statusLabel + '</span></td>' +
      '</tr>'
    );
  }).join('');
}

// ==========================================
// DELAY FORECAST SIDEBAR — per upcoming station
// ==========================================
function renderForecastSidebar(t){
  var card = document.getElementById('eta-forecast-card');
  var listEl = document.getElementById('eta-forecast-list');
  var upcoming = (t.eta.propagation || []);

  if(!upcoming.length){ return; }
  card.classList.remove('hidden');

  listEl.innerHTML = upcoming.map(function(p){
    var sign = p.delayMin > 0 ? '+' : '';
    return (
      '<div class="forecast-row">' +
        '<span class="fr-stn"><svg class="icon" viewBox="0 0 24 24"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>' + p.station + '</span>' +
        '<span class="fr-val">' + (p.delayMin === 0 ? 'On time' : sign + p.delayMin + ' min') + '</span>' +
      '</div>'
    );
  }).join('');
}

// ==========================================
// WHY IS THE ETA DIFFERENT?
// Only shows factors that are actually in the data — never an
// invented specific cause like "signal failure".
// ==========================================
function renderFactors(t){
  var listEl = document.getElementById('eta-factors-list');
  var summaryEl = document.getElementById('eta-factors-summary');

  if(!t.eta.factors || !t.eta.factors.length){
    if(summaryEl) summaryEl.textContent = 'Reason currently unavailable. The prediction is based on current running data and historical patterns.';
    listEl.innerHTML = '';
    return;
  }

  if(summaryEl) summaryEl.textContent = t.eta.explanationSummary || 'The prediction is recalculated from the latest running snapshot and model inputs.';

  var rows = t.eta.factors.map(function(f){
    var sign = f.minutes > 0 ? '+' : '';
    var cls = f.minutes > 0 ? 'positive' : (f.minutes < 0 ? 'negative' : 'neutral');
    return '<div class="factor-row">' +
      '<div class="factor-copy"><span class="factor-label">' + f.label + '</span><small>' + (f.detail || '') + '</small></div>' +
      '<b class="' + cls + '">' + sign + f.minutes + ' min</b>' +
    '</div>';
  }).join('');

  var total = t.eta.factors.reduce(function(sum, f){ return sum + f.minutes; }, 0);
  var totalLabel = total > 0 ? '+' + total + ' min' : (total < 0 ? total + ' min' : 'On time');
  listEl.innerHTML = rows + '<div class="eta-factors-total"><span>Final predicted delay</span><span>' + totalLabel + '</span></div>' +
    '<div class="eta-factors-note">Prototype explanation: these factors describe the ETA model inputs. A specific operational cause is shown only when verified live railway data provides it.</div>';
}

// ==========================================
// ETA HISTORY — shown for lighter trains without a full
// stop-by-stop schedule, if history data exists
// ==========================================
function renderHistory(t){
  if(!t.eta.history || !t.eta.history.length) return;
  document.getElementById('eta-history-card').classList.remove('hidden');

  document.getElementById('eta-history-list').innerHTML = t.eta.history.map(function(h, i){
    var isLast = i === t.eta.history.length - 1;
    return (
      '<div class="eh-row">' +
        '<div class="eh-dot-col"><div class="eh-dot"></div><div class="eh-line"></div></div>' +
        '<div class="eh-info">' +
          '<div class="time">' + h.time + '</div>' +
          '<div class="label">' + h.label + '</div>' +
          '<div class="eta-val">' + h.eta + '</div>' +
        '</div>' +
      '</div>'
    );
  }).join('');
}

// ==========================================
// UPCOMING STATION PREDICTIONS (fallback table for lighter trains)
// ==========================================
function renderPropagation(t){
  if(!t.eta.propagation || !t.eta.propagation.length) return;
  document.getElementById('eta-propagation-card').classList.remove('hidden');

  document.getElementById('propagation-body').innerHTML = t.eta.propagation.map(function(p){
    var sign = p.delayMin > 0 ? '+' : '';
    return (
      '<tr>' +
        '<td class="stn">' + p.station + '</td>' +
        '<td>' + p.scheduled + '</td>' +
        '<td>' + p.predicted + '</td>' +
        '<td style="color:' + (p.delayMin > 0 ? 'var(--amber)' : 'var(--green)') + ';font-weight:700;">' + sign + p.delayMin + ' min</td>' +
      '</tr>'
    );
  }).join('');
}

// ==========================================
// SMS OPT-IN — demo only, no real SMS is sent in this prototype
// ==========================================
var smsBtn = document.getElementById('eta-sms-btn');
if(smsBtn){
  smsBtn.addEventListener('click', function(){
    var input = document.getElementById('eta-sms-input');
    var val = (input.value || '').trim();
    if(!/^\d{10}$/.test(val)){
      showToast('Enter a valid 10-digit mobile number');
      return;
    }
    showToast('This is a prototype — no real SMS is sent');
    input.value = '';
  });
}
