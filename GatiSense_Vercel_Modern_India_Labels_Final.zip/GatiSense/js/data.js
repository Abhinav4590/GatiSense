/* ==========================================================
   GATISENSE — CENTRALIZED DEMO DATA
   This is the single source of truth for train information
   in the prototype, so the same train shows the same status
   everywhere (Search, Tracking, ETA, Live Station, My Trains,
   Notifications) rather than each page inventing its own
   numbers.

   This is clearly demo/simulated data — see DEMO_LABEL below.
   In a real build, the functions at the bottom of this file
   (getTrain, searchTrains, getStationArrivals) would be
   replaced with calls to a FastAPI backend, e.g.:
       fetch('/api/trains/12951/status')
   instead of reading from the GATI_TRAINS array. The rest of
   each page's JS would not need to change.
   ========================================================== */

var DEMO_LABEL = 'Demo Data — simulated for this prototype';

// ==========================================
// STATION COORDINATES
// Real approximate latitude/longitude for major stations
// across India, so the Leaflet maps on the Tracking and
// Railway Map pages plot genuine geographic positions and
// every major city can be searched — not just the handful
// of stations that happen to be on a demo train's route.
// ==========================================
var STATION_COORDS = {
  // ---- North ----
  'New Delhi':          [28.6139, 77.2090],
  'Old Delhi':           [28.6667, 77.2167],
  'Hazrat Nizamuddin':    [28.5877, 77.2508],
  'Chandigarh':            [30.7333, 76.7794],
  'Amritsar':               [31.6340, 74.8723],
  'Jammu Tawi':              [32.7266, 74.8570],
  'Ludhiana':                 [30.9010, 75.8573],
  'Jaipur':                    [26.9124, 75.7873],
  'Jodhpur':                    [26.2389, 73.0243],
  'Udaipur':                     [24.5854, 73.7125],
  'Ajmer':                        [26.4499, 74.6399],
  'Agra Cantt':                    [27.1767, 78.0081],
  'Mathura Junction':               [27.4924, 77.6737],
  'Aligarh':                         [27.8974, 78.0880],
  'Tundla Junction':                  [27.2167, 78.2333],
  'Dholpur':                           [26.7017, 77.8898],
  'Etawah':                           [26.7855, 79.0154],
  'Kanpur Central':                 [26.4499, 80.3319],
  'Lucknow':                         [26.8467, 80.9462],
  'Ayodhya':                          [26.7922, 82.1998],
  'Sonipat':                        [28.9958, 77.0092],
  'Panipat':                          [29.3909, 76.9635],
  'Kurukshetra Junction':              [29.9695, 76.8783],
  'Ambala Cantt':                    [30.3752, 76.7821],
  'Dehradun':                         [30.3165, 78.0322],
  'Haridwar':                          [29.9457, 78.1642],
  'Kota Junction':                      [25.1804, 75.8648],
  'Sawai Madhopur':                      [26.0173, 76.3520],
  'Bharatpur':                             [27.2173, 77.4901],
  'Gwalior':                                [26.2183, 78.1828],
  'Jhansi Junction':                         [25.4484, 78.5685],
  'Bina Junction':                            [24.1833, 78.2167],
  'Varanasi':                                 [25.3176, 82.9739],
  'Prayagraj Junction':                        [25.4358, 81.8463],
  'Gorakhpur':                                   [26.7606, 83.3732],
  'Barauni Junction':                             [25.4667, 85.9667],
  'Katihar Junction':                             [25.5386, 87.5872],
  'Gaya':                                         [24.7955, 84.9994],
  'Patna':                                        [25.5941, 85.1376],
  'Dhanbad':                                       [23.7957, 86.4304],
  'Asansol':                                        [23.6739, 86.9524],
  'Ranchi':                                        [23.3441, 85.3096],

  // ---- West ----
  'Mumbai Central':      [18.9696, 72.8194],
  'Mumbai CST':           [18.9398, 72.8355],
  'Vadodara':              [22.3072, 73.1812],
  'Surat':                  [21.1702, 72.8311],
  'Ahmedabad':               [23.0225, 72.5714],
  'Rajkot':                   [22.3039, 70.8022],
  'Pune':                       [18.5204, 73.8567],
  'Nagpur':                      [21.1458, 79.0882],
  'Itarsi':                       [22.6083, 77.7642],
  'Nashik Road':                  [19.9975, 73.7898],
  'Indore':                         [22.7196, 75.8577],
  'Bhopal':                          [23.2599, 77.4126],
  'Jabalpur':                         [23.1815, 79.9864],
  'Raipur':                            [21.2514, 81.6296],

  // ---- South ----
  'Chennai Central':     [13.0827, 80.2707],
  'Bengaluru City':       [12.9716, 77.5946],
  'Secunderabad':          [17.4399, 78.4983],
  'Guntakal Junction':      [15.1667, 77.3667],
  'Anantapur':               [14.6819, 77.6006],
  'Vijayawada':             [16.5062, 80.6480],
  'Tenali Junction':         [16.2429, 80.6400],
  'Ongole':                   [15.5057, 80.0499],
  'Nellore':                   [14.4426, 79.9865],
  'Gudur Junction':             [14.1487, 79.8481],
  'Visakhapatnam':           [17.6868, 83.2185],
  'Rajahmundry':              [17.0005, 81.7799],
  'Salem':                      [11.6643, 78.1460],
  'Erode':                       [11.3410, 77.7172],
  'Coimbatore':                [11.0168, 76.9558],
  'Madurai':                     [9.9252, 78.1198],
  'Thiruvananthapuram':           [8.5241, 76.9366],
  'Kollam':                        [8.8932, 76.6141],
  'Ernakulam':                      [9.9816, 76.2999],
  'Thrissur':                       [10.5276, 76.2144],
  'Mysuru':                          [12.2958, 76.6394],

  // ---- East ----
  'Howrah':               [22.5851, 88.3468],
  'Sealdah':                [22.5697, 88.3697],
  'Bhubaneswar':             [20.2961, 85.8245],
  'Guwahati':                 [26.1445, 91.7362],
  'Dibrugarh':                 [27.4728, 94.9120],
  'New Jalpaiguri':              [26.6839, 88.4302],
  'Hazrat Nizamuddin':            [28.5880, 77.2510],
  'Kalka':                         [30.8398, 76.9384],
  'Hisar':                         [29.1492, 75.7217],
  'Anand Vihar':                   [28.6469, 77.3160],
  'Shri Mata Vaishno Devi Katra': [32.9916, 74.9311],
  'Madgaon':                       [15.2993, 74.1240],
  'Bilaspur':                      [22.0797, 82.1409],
  'Manduadih':                     [25.3209, 83.0060],
  'Patliputra':                    [25.6170, 85.0910],
  'Yesvantpur':                    [13.0285, 77.5480],
  'KSR Bengaluru':                 [12.9784, 77.5699],
  'Kochuveli':                     [8.5080, 76.9040],
  'Durg':                          [21.1904, 81.2849],
  'Amritsar Junction':             [31.6340, 74.8723],
  'Jabalpur':                      [23.1815, 79.9864],
  'Rajendra Nagar Terminal':       [25.6100, 85.0900],
  'Jaynagar':                      [26.5907, 86.1360],
  'Agra Fort':                     [27.1795, 78.0211],
  'Kochi':                         [9.9312, 76.2673],
  'Asansol':                       [23.6739, 86.9524],
  'Bokaro':                        [23.6693, 86.1511],
  'Bhusaval':                      [21.0465, 75.7812],
  'Delhi':                         [28.6139, 77.2090],
  'Delhi S Rohilla':               [28.6675, 77.1556],
  'Cuttack':                       [20.4625, 85.8830],
  'Kharagpur':                     [22.3460, 87.2320],
  'Tirupati':                      [13.6288, 79.4192],
  'Tirupati Railway Station':      [13.6288, 79.4192],
  'Bhubaneswar':                   [20.2961, 85.8245]
};


// Railway-station coordinates used by highlighted train routes. These are
// station-point coordinates rather than city-centre coordinates, which keeps
// route markers on the actual railway station instead of nearby city labels.
var GATI_ROUTE_STATION_COORD_OVERRIDES = {
  'New Delhi':[28.642314,77.220004],
  'Mumbai Central':[18.9696,72.8194],
  'Borivali':[19.228739,72.856412],
  'Surat':[21.206568,72.840793],
  'Vadodara':[22.310756,73.181065],
  'Ratlam':[23.34038,75.050826],
  'Nagda':[23.45592,75.412491],
  'Kota Junction':[25.198051,75.885111],
  'Sawai Madhopur':[26.018279,76.35622],
  'Bharatpur':[27.237107,77.488613],
  'Agra Cantt':[27.157992,77.990153],
  'Mathura Junction':[27.480145,77.673117],
  'Aligarh':[27.889584,78.074559],
  'Tundla Junction':[27.207747,78.233285],
  'Etawah':[26.78597,79.021502],
  'Gwalior':[26.2151,78.18283],
  'Jhansi Junction':[25.443585,78.552985],
  'Bina Junction':[24.170974,78.1832],
  'Bhopal':[23.266884,77.413143],
  'Gaya':[24.803978,84.999294],
  'Dhanbad':[23.790966,86.428956],
  'Asansol':[23.691441,86.975152],
  'Gorakhpur':[26.759311,83.381499],
  'Barauni Junction':[25.461768,85.988748],
  'New Jalpaiguri':[26.683025,88.443391],
  'Kanpur Central':[26.45424,80.350966],
  'Prayagraj Junction':[25.4358,81.8463],
  'Varanasi':[25.3176,82.9739],
  'Panipat':[29.388948,76.963793],
  'Kharagpur':[22.34601,87.232],
  'Salem':[11.671726,78.113415],
  'Erode':[11.327682,77.725934],
  'Coimbatore':[10.997639,76.966298],
  'Madurai':[9.919907,78.110314],
  'Kollam':[8.886586,76.596753],
  'Ernakulam':[9.969542,76.290672],
  'Mysuru':[12.318946,76.646013],
  'Secunderabad':[17.433147,78.501481],
  'Guntakal Junction':[15.17556,77.366611],
  'Anantapur':[14.686478,77.595312],
  'Tenali Junction':[16.242409,80.640413],
  'Ongole':[15.498064,80.057404],
  'Nellore':[14.460592,79.989383],
  'Gudur Junction':[14.148227,79.845121],
  'Katihar Junction':[25.548947,87.566409],
  'Chennai Central':[13.084761,80.274856]
};

Object.keys(GATI_ROUTE_STATION_COORD_OVERRIDES).forEach(function(name){
  STATION_COORDS[name] = GATI_ROUTE_STATION_COORD_OVERRIDES[name];
});

// ==========================================
// RAILWAY NETWORK CORRIDORS
// A set of real major trunk routes (not tied to any one demo
// train), so the Railway Map page shows an actual national
// network diagram rather than only the handful of routes the
// sample trains happen to run on.
// ==========================================
var RAIL_CORRIDORS = [
  ['New Delhi','Kanpur Central','Prayagraj Junction','Varanasi','Patna','Howrah'],
  ['New Delhi','Agra Cantt','Gwalior','Jhansi Junction','Bhopal','Nagpur'],
  ['New Delhi','Kota Junction','Sawai Madhopur','Vadodara','Mumbai Central'],
  ['New Delhi','Jaipur','Ajmer','Jodhpur'],
  ['New Delhi','Chandigarh','Ludhiana','Amritsar','Jammu Tawi'],
  ['New Delhi','Lucknow','Gorakhpur'],
  ['New Delhi','Hazrat Nizamuddin','Dehradun'],
  ['Mumbai Central','Surat','Vadodara','Ahmedabad','Rajkot'],
  ['Mumbai CST','Pune','Bengaluru City'],
  ['Nagpur','Raipur','Bhubaneswar'],
  ['Secunderabad','Guntakal Junction','Anantapur','Bengaluru City'],
  ['Howrah','Bhubaneswar','Visakhapatnam','Vijayawada','Tenali Junction','Ongole','Nellore','Gudur Junction','Chennai Central'],
  ['Chennai Central','Bengaluru City','Mysuru'],
  ['Chennai Central','Salem','Erode','Coimbatore','Thrissur','Ernakulam','Thiruvananthapuram'],
  ['Bhopal','Indore'],
  ['Howrah','New Jalpaiguri','Guwahati','Dibrugarh'],
  ['Nagpur','Jabalpur','Varanasi']
];

// ==========================================
// REALISTIC ROUTE WAYPOINTS
// For trains that only have a source + destination (no full
// stop-by-stop schedule), this supplies the real junction
// cities the route actually passes through, so the route line
// on the maps bends along the genuine rail corridor instead of
// cutting a straight "as the crow flies" line between the two
// endpoints. Keyed by train number; only intermediate stations
// (not source/destination) are listed here.
// ==========================================
var TRAIN_ROUTE_WAYPOINTS = {
  // 12951 follows the published Mumbai Central–New Delhi corridor.
  // These are route geometry points (not necessarily every booked halt),
  // so the highlighted line follows the real corridor rather than a
  // smoothed curve through only six cities.
  '12951': ['Borivali','Surat','Vadodara','Ratlam','Nagda','Kota'],

  '12301': ['Asansol','Dhanbad','Gaya','Varanasi','Prayagraj Junction','Kanpur Central'],
  '12002': ['Mathura Junction','Agra Cantt','Gwalior','Jhansi Junction','Bina Junction'],
  '12004': ['Aligarh','Tundla Junction','Etawah','Kanpur Central'],
  '12423': ['Kanpur Central','Prayagraj Junction','Varanasi','Barauni Junction','Katihar Junction','New Jalpaiguri','Guwahati'],
  '12555': ['Lucknow','Kanpur Central','New Delhi','Rohtak','Bhiwani','Hisar'],
  '12005': ['Panipat','Kurukshetra Junction','Ambala Cantt','Chandigarh'],
  '12626': ['Mathura Junction','Agra Cantt','Gwalior','Jhansi Junction','Bina Junction','Bhopal','Itarsi','Nagpur','Vijayawada','Chennai Central','Salem','Erode','Coimbatore','Ernakulam','Thiruvananthapuram'],
  '12648': ['Mathura Junction','Agra Cantt','Gwalior','Jhansi Junction','Bina Junction','Bhopal','Itarsi','Nagpur','Guntakal Junction','Anantapur','Salem','Erode','Coimbatore'],
  '12425': ['Ludhiana','Ambala Cantt','Jammu Tawi'],
  '12437': ['Nagpur','Bhopal','Jhansi Junction','Hazrat Nizamuddin'],
  '12439': ['Bokaro','Dhanbad','Gaya','Prayagraj Junction','Kanpur Central','New Delhi'],
  '12441': ['Raipur','Nagpur','Bhopal','Jhansi Junction','Gwalior','New Delhi'],
  '12445': ['Panipat','Ambala Cantt','Ludhiana','Jammu Tawi','Shri Mata Vaishno Devi Katra'],
  '12449': ['Ratnagiri','Panvel','Vasai Road','Surat','Vadodara','Ratlam','Kota Junction','Hazrat Nizamuddin','New Delhi','Panipat','Chandigarh'],
  '12451': ['Etawah','Aligarh','New Delhi'],
  '12501': ['Guwahati','New Jalpaiguri','Katihar Junction','Barauni Junction','Patna','Kanpur Central','New Delhi'],
  '12505': ['Guwahati','New Jalpaiguri','Katihar Junction','Barauni Junction','Patna','Kanpur Central','New Delhi'],
  '12533': ['Kanpur Central','Jhansi Junction','Bhopal','Itarsi','Nagpur','Bhusaval','Nashik Road','Mumbai CST'],
  '12541': ['Lucknow','Kanpur Central','Jhansi Junction','Bhopal','Itarsi','Nashik Road','Mumbai CST'],
  '12553': ['Patna','Barauni Junction','Gaya','Kanpur Central','New Delhi'],
  '12559': ['Prayagraj Junction','Kanpur Central','New Delhi'],
  '12615': ['Vijayawada','Nagpur','Bhopal','Bina Junction','Gwalior','Agra Cantt','Mathura Junction','Hazrat Nizamuddin','New Delhi'],
  '12621': ['Vijayawada','Nagpur','Itarsi','Bhopal','Jhansi Junction','Gwalior','Agra Cantt','Hazrat Nizamuddin','New Delhi'],
  '12627': ['Bengaluru City','Guntakal Junction','Bhusaval','Itarsi','Bhopal','Bina Junction','Jhansi Junction','Gwalior','Agra Cantt','Mathura Junction','Hazrat Nizamuddin','New Delhi'],
  '12815': ['Bhubaneswar','Cuttack','Kharagpur','Gaya','Prayagraj Junction','Kanpur Central','New Delhi'],
  '12708': ['Tirupati','Secunderabad','Nagpur','Bhopal','Jhansi Junction','Gwalior','Agra Cantt','Mathura Junction','Hazrat Nizamuddin']
};

// ==========================================
// TRAIN 12951 — MUMBAI RAJDHANI EXPRESS
// This is the fully detailed "hero" train used to demonstrate
// live tracking and dynamic ETA prediction end-to-end.
// ==========================================
var TRAIN_12951 = {
  number: '12951',
  name: 'Mumbai Rajdhani Express',
  type: 'Rajdhani · Superfast',
  runningDays: 'Daily',
  source: 'Mumbai Central',
  destination: 'New Delhi',
  distanceKm: 1384,
  status: 'running', // running | ontime | cancelled | rescheduled | diverted

  // Full stop list with scheduled times. "actual" is filled in
  // only for stations already reached; future stations show
  // predicted values instead (calculated, not invented).
  stops: [
    { code: 'MMCT', name: 'Mumbai Central', schedArr: null,    schedDep: '17:00', actualArr: null, actualDep: '17:00', state: 'departed' },
    { code: 'BVI',  name: 'Borivali',      schedArr: '17:20', schedDep: '17:22', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'ST',   name: 'Surat',         schedArr: '19:43', schedDep: '19:48', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'BRC',  name: 'Vadodara',      schedArr: '21:06', schedDep: '21:16', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'RTM',  name: 'Ratlam',        schedArr: '00:25', schedDep: '00:28', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'NAD',  name: 'Nagda',         schedArr: '01:08', schedDep: '01:10', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'KOTA', name: 'Kota Junction', schedArr: '03:15', schedDep: '03:20', actualArr: null, actualDep: null, state: 'departed' },
    { code: 'NDLS', name: 'New Delhi',     schedArr: '08:32', schedDep: null,    actualArr: null, actualDep: null, state: 'upcoming' }
  ],

  // Exact booked-stop corridor used by the Live Tracking route timeline.
  // These are the current scheduled calls for 12951; it does not call at
  // Sawai Madhopur, Bharatpur or Mathura.
  routeWaypoints: ['Mumbai Central','Borivali','Surat','Vadodara','Ratlam','Nagda','Kota Junction','New Delhi'],

  // Current live snapshot — the train is currently between
  // Kota Junction (last departed) and Sawai Madhopur (next).
  live: {
    currentDelayMin: 12,
    previousStationDelayMin: 10,
    lastUpdatedMinsAgo: 2,
    currentLocationText: 'Between Kota Junction and Sawai Madhopur',
    currentPosition: [25.43, 76.01],
    nextStation: 'Sawai Madhopur',
    nextStationEta: '17:46'
  },

  // Everything the ETA Prediction page needs to explain the
  // prediction in plain language (no ML jargon).
  eta: {
    scheduledArrival: '08:32',
    predictedArrival: '08:42',
    predictedDelayMin: 10,
    confidence: 'High',
    confidencePct: 89,
    distanceRemainingKm: 180,
    avgSpeedKmh: 75,
    stopsRemaining: 1,
    // Only data-supported factors — no invented causes like
    // "signal failure" per the project rule.
    factors: [
      { label: 'Current running delay', minutes: 12 },
      { label: 'Delay at previous station (Kota Junction)', minutes: 10 },
      { label: 'Historical average delay on this route', minutes: 8 },
      { label: 'Expected recovery further along the route', minutes: -2 }
    ],
    // How the prediction has changed as new running data came in.
    history: [
      { time: '17:20', label: 'Initial prediction', eta: '20:44' },
      { time: '17:29', label: 'Updated after latest running data', eta: '20:42' },
      { time: '17:33', label: 'Updated after expected recovery', eta: '20:40' }
    ],
    // Predicted delay at each upcoming station (delay propagation).
    propagation: [
      { station: 'New Delhi', scheduled: '08:32', predicted: '08:42', delayMin: 10 }
    ]
  }
};

// ==========================================
// OTHER TRAINS
// Lighter-detail records — enough for search results, station
// arrival boards and My Trains, without a full stop-by-stop
// schedule for every single one.
// ==========================================
var GATI_TRAINS = [
  TRAIN_12951,
  {
    number: '12301', name: 'Howrah–New Delhi Rajdhani Express', type: 'Rajdhani · Superfast', runningDays: 'Daily',
    source: 'Howrah', destination: 'New Delhi', distanceKm: 1449, status: 'ontime',
    live: { currentDelayMin: 0, lastUpdatedMinsAgo: 4, currentLocationText: 'Near Kanpur Central', nextStation: 'Prayagraj Junction', nextStationEta: '16:20' },
    eta: { scheduledArrival: '10:00', predictedArrival: '10:00', predictedDelayMin: 0, confidence: 'High', confidencePct: 92 }
  },
  {
    number: '12002', name: 'Bhopal Shatabdi', type: 'Shatabdi · Superfast', runningDays: 'Daily except Sunday',
    source: 'New Delhi', destination: 'Bhopal', distanceKm: 702, status: 'running',
    live: { currentDelayMin: 9, lastUpdatedMinsAgo: 6, currentLocationText: 'Near Jhansi Junction', nextStation: 'Gwalior', nextStationEta: '13:40' },
    eta: { scheduledArrival: '14:10', predictedArrival: '14:19', predictedDelayMin: 9, confidence: 'Moderate', confidencePct: 74 }
  },
  {
    number: '12004', name: 'Lucknow Shatabdi', type: 'Shatabdi · Superfast', runningDays: 'Daily except Sunday',
    source: 'New Delhi', destination: 'Lucknow', distanceKm: 497, status: 'running',
    live: { currentDelayMin: 7, lastUpdatedMinsAgo: 3, currentLocationText: 'Approaching Kanpur Central', nextStation: 'Kanpur Central', nextStationEta: '18:37' },
    eta: { scheduledArrival: '18:30', predictedArrival: '18:37', predictedDelayMin: 7, confidence: 'High', confidencePct: 90 }
  },
  {
    number: '12423', name: 'Dibrugarh Rajdhani', type: 'Rajdhani · Superfast', runningDays: 'Tue, Fri, Sun',
    source: 'New Delhi', destination: 'Dibrugarh', distanceKm: 2438, status: 'running',
    live: { currentDelayMin: 7, lastUpdatedMinsAgo: 5, currentLocationText: 'Near Gorakhpur', nextStation: 'Kanpur Central', nextStationEta: '15:12' },
    eta: { scheduledArrival: '15:05', predictedArrival: '15:12', predictedDelayMin: 7, confidence: 'Moderate', confidencePct: 68 }
  },
  {
    number: '12555', name: 'Gorakdam Express', type: 'Superfast', runningDays: 'Daily',
    source: 'Gorakhpur', destination: 'Hisar', distanceKm: 1060, status: 'running',
    live: { currentDelayMin: 0, lastUpdatedMinsAgo: 0, currentLocationText: 'Calculating position…', nextStation: '', nextStationEta: '' },
    eta: { scheduledArrival: '10:00', predictedArrival: '10:00', predictedDelayMin: 0, confidence: 'High', confidencePct: 90 }
  },
  {
    number: '12005', name: 'Kalka Shatabdi', type: 'Shatabdi · Superfast', runningDays: 'Daily',
    source: 'New Delhi', destination: 'Kalka', distanceKm: 303, status: 'ontime',
    live: { currentDelayMin: 0, lastUpdatedMinsAgo: 1, currentLocationText: 'Between Ambala Cantt and Chandigarh', nextStation: 'Kalka', nextStationEta: '21:15' },
    eta: { scheduledArrival: '21:15', predictedArrival: '21:15', predictedDelayMin: 0, confidence: 'High', confidencePct: 94 }
  },
  {
    number: '12626', name: 'Kerala Express', type: 'Express', runningDays: 'Daily',
    source: 'New Delhi', destination: 'Thiruvananthapuram', distanceKm: 3054, status: 'running',
    live: { currentDelayMin: 22, lastUpdatedMinsAgo: 10, currentLocationText: 'Near Nagpur (diverted route)', nextStation: 'Nagpur', nextStationEta: '—' },
    eta: { scheduledArrival: '05:15', predictedArrival: '05:40', predictedDelayMin: 25, confidence: 'Moderate', confidencePct: 65 }
  },
  {
    number: '12648', name: 'Kongu Express', type: 'Superfast', runningDays: 'Weekly',
    source: 'Hazrat Nizamuddin', destination: 'Coimbatore', distanceKm: 2687, status: 'ontime',
    live: { currentDelayMin: 6, lastUpdatedMinsAgo: 2, currentLocationText: 'Near Nagpur', nextStation: 'Balharshah', nextStationEta: '02:20' },
    eta: { scheduledArrival: '06:30', predictedArrival: '06:36', predictedDelayMin: 6, confidence: 'Moderate', confidencePct: 82 }
  }
];

// ==========================================
// EXPANDED REAL-WORLD TRAIN CATALOGUE
// Train numbers, names, source and destination are based on
// Indian Railways/CRIS published train lists. Running status and
// ETA below are intentionally simulated for this prototype until
// a live NTES/authorized running-status API is connected.
// ==========================================
var EXTRA_GATI_TRAINS = [
  ['12425','Jammu Rajdhani','Rajdhani · Superfast','New Delhi','Jammu Tawi',577,'Daily','20:40','05:45',505,5],
  ['12437','Rajdhani Express','Rajdhani · Superfast','Secunderabad','Hazrat Nizamuddin',1669,'Daily','12:45','10:25',1300,8],
  ['12439','Ranchi Rajdhani','Rajdhani · Superfast','Ranchi','New Delhi',1300,'Weekly','17:55','10:50',1015,7],
  ['12441','Bilaspur Rajdhani','Rajdhani · Superfast','Bilaspur','New Delhi',1380,'Weekly','14:00','10:55',1015,4],
  ['12445','Uttar Sampark Kranti','Superfast','New Delhi','Shri Mata Vaishno Devi Katra',655,'Daily','20:50','08:40',710,6],
  ['12449','Goa Sampark Kranti','Superfast','Madgaon','Chandigarh',2088,'Weekly','11:20','23:45',2185,9],
  ['12451','Shram Shakti Express','Superfast','Kanpur Central','New Delhi',438,'Daily','23:45','06:35',410,3],
  ['12501','Poorvottar Sampark Kranti','Superfast','Guwahati','New Delhi',1984,'Weekly','06:15','13:00',1845,10],
  ['12505','North East Express','Superfast','Guwahati','Anand Vihar',1890,'Daily','09:45','19:20',1775,11],
  ['12533','Pushpak Express','Superfast','Lucknow','Mumbai CST',1500,'Daily','19:45','20:15',1470,8],
  ['12541','GKP LTT Superfast Express','Superfast','Gorakhpur','Mumbai CST',1690,'Daily','21:50','04:00',1570,12],
  ['12553','Vaishali Express','Superfast','Barauni Junction','New Delhi',1220,'Daily','09:30','06:45',1275,5],
  ['12559','Shiv Ganga Express','Superfast','Manduadih','New Delhi',760,'Daily','19:40','08:10',750,7],
  ['12615','Grand Trunk Express','Superfast','Chennai Central','Delhi S Rohilla',2176,'Daily','19:15','07:10',2155,6],
  ['12621','Tamil Nadu Express','Superfast','Chennai Central','New Delhi',2182,'Daily','22:00','07:05',1985,9],
  ['12627','Karnataka Express','Superfast','KSR Bengaluru','New Delhi',2401,'Daily','19:20','10:30',2280,4],
  ['12815','Nandan Kanan Express','Superfast','Puri','New Delhi',1867,'Daily','10:55','17:05',1810,8],
  ['12708','AP Sampark Kranti','Superfast','Hazrat Nizamuddin','Tirupati',2300,'Weekly','07:10','21:35',2310,7]
];

function buildExtraTrain(row){
  return {
    number: row[0], name: row[1], type: row[2], runningDays: row[6],
    source: row[3], destination: row[4], distanceKm: row[5], status: 'running',
    service: { departure: row[7], arrival: row[8], durationMin: row[9], seedDelayMin: row[10] },
    dynamic: true,
    live: { currentDelayMin: row[10], lastUpdatedMinsAgo: 0, currentLocationText: 'Calculating position…', nextStation: '', nextStationEta: '' },
    eta: { scheduledArrival: row[8], predictedArrival: row[8], predictedDelayMin: row[10], confidence: 'Prototype', confidencePct: 82 }
  };
}

for(var ei = 0; ei < EXTRA_GATI_TRAINS.length; ei++){
  GATI_TRAINS.push(buildExtraTrain(EXTRA_GATI_TRAINS[ei]));
}

// Attach service metadata to the original nine prototype records so
// every train uses the same dynamic ETA engine.
var SERVICE_META = {
  '12951':['17:00','08:32',932,12],
  '12301':['16:50','10:05',1035,0],
  '12002':['06:00','14:25',505,9],
  '12004':['06:10','12:40',390,7],
  '12423':['20:35','10:20',825,7],
  '12555':['16:35','10:00',1045,0],
  '12005':['17:15','21:15',240,0],
  '12626':['11:25','14:45',1640,22],
  '12648':['07:00','06:30',1410,6]
};
Object.keys(SERVICE_META).forEach(function(num){
  var tr = GATI_TRAINS.filter(function(x){ return x.number === num; })[0];
  if(tr){
    var m = SERVICE_META[num];
    tr.service = { departure:m[0], arrival:m[1], durationMin:m[2], seedDelayMin:m[3] };
    tr.dynamic = true;
  }
});

// Dynamic prototype ETA engine. It uses the real scheduled journey
// window as the baseline and applies a small deterministic running
// variation so each train updates independently on the user's clock.
// This is NOT live railway telemetry.
function minutesNow(){
  var d = new Date();
  return d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
}
function clockMinutes(hhmm){
  var p = (hhmm || '00:00').split(':');
  return parseInt(p[0],10) * 60 + parseInt(p[1],10);
}
function formatClock(total){
  total = ((Math.round(total) % 1440) + 1440) % 1440;
  var h = Math.floor(total/60), m = total % 60;
  return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
}
function updateDynamicTrain(t){
  if(!t || !t.dynamic || !t.service) return t;
  var dep = clockMinutes(t.service.departure);
  var duration = t.service.durationMin;
  var now = minutesNow();
  var elapsed = now - dep;
  if(elapsed < 0) elapsed += 1440;
  var inJourney = elapsed >= 0 && elapsed <= duration;
  if(!inJourney){
    // Keep the selected train useful even outside today's running window:
    // show the next scheduled arrival and a neutral "scheduled/completed" snapshot.
    var nextArrival = clockMinutes(t.service.arrival) + (now >= clockMinutes(t.service.arrival) ? 1440 : 0);
    var nextDelay = now < dep ? (t.service.seedDelayMin || 0) : 0;
    t.live.currentDelayMin = nextDelay;
    t.live.lastUpdatedMinsAgo = 0;
    t.live.currentLocationText = now < dep ? 'Scheduled to depart from ' + t.source : 'Journey completed — next service at ' + t.service.departure;
    t.live.nextStation = now < dep ? t.source : t.destination;
    t.live.nextStationEta = now < dep ? t.service.departure : formatClock(nextArrival);
    t.eta.scheduledArrival = t.service.arrival;
    t.eta.predictedArrival = formatClock(nextArrival + nextDelay);
    t.eta.predictedDelayMin = nextDelay;
    t.eta.confidencePct = 80 + (parseInt(t.number.slice(-1),10) % 16);
    t.eta.confidence = t.eta.confidencePct >= 90 ? 'High' : 'Moderate';
    refreshEtaExplanation(t, nextDelay, false);
    return t;
  }

  var wave = Math.round(Math.sin((now + parseInt(t.number.slice(-2),10)) / 18) * 3);
  var delay = Math.max(0, Math.round((t.service.seedDelayMin || 0) + wave));
  var effectiveElapsed = Math.max(0, elapsed - delay * 0.55);
  var progress = Math.min(0.985, effectiveElapsed / duration);
  var route = getRoutePoints(t);
  if(route.length >= 2){
    var scaled = progress * (route.length - 1);
    var leg = Math.min(route.length - 2, Math.floor(scaled));
    var frac = scaled - leg;
    var a = route[leg].coord, b = route[leg+1].coord;
    t.live.currentPosition = [a[0] + (b[0]-a[0])*frac, a[1] + (b[1]-a[1])*frac];
    t.live.currentLocationText = 'Between ' + route[leg].name + ' and ' + route[leg+1].name;
    t.live.nextStation = route[leg+1].name;
    var etaToNext = Math.max(1, Math.round((1-frac) * (duration/(route.length-1))));
    t.live.nextStationEta = formatClock(now + etaToNext + delay);
  } else {
    t.live.currentLocationText = 'En route from ' + t.source + ' to ' + t.destination;
    t.live.nextStation = t.destination;
    t.live.nextStationEta = formatClock(now + Math.max(1, duration - elapsed) + delay);
  }
  t.live.currentDelayMin = delay;
  t.live.lastUpdatedMinsAgo = 0;
  t.eta.scheduledArrival = t.service.arrival;
  t.eta.predictedArrival = formatClock(clockMinutes(t.service.arrival) + delay);
  t.eta.predictedDelayMin = delay;
  t.eta.confidencePct = 82 + (parseInt(t.number.slice(-1),10) % 15);
  t.eta.confidence = t.eta.confidencePct >= 90 ? 'High' : 'Moderate';
  refreshEtaExplanation(t, delay, true);
  return t;
}

// Builds the passenger-facing explanation behind every prototype ETA.
// These are model inputs, not claims about a specific operational incident.
// A future live data source can replace these fields with verified causes such
// as congestion, weather, signalling, maintenance or a control-room alert.
function refreshEtaExplanation(t, delay, inJourney){
  delay = Math.max(0, Number(delay) || 0);
  var carried = Math.round(delay * 0.30);
  var historical = Math.round(delay * 0.35);
  var running = delay - carried - historical;
  var recovery = delay > 0 ? -Math.min(5, Math.max(0, Math.round(delay * 0.12))) : 0;
  // Keep the displayed factors mathematically consistent with the ETA.
  running = delay - carried - historical - recovery;

  var factors = [
    { label: 'Current running delay', minutes: running, detail: delay > 0 ? 'Latest simulated running deviation from schedule.' : 'No current running deviation.' },
    { label: 'Delay carried from previous station', minutes: carried, detail: carried > 0 ? 'Part of the existing delay is propagating forward.' : 'No carried delay is currently modeled.' },
    { label: 'Historical average delay on this route', minutes: historical, detail: historical > 0 ? 'Prototype historical-pattern component used by the ETA model.' : 'Historical pattern is not adding delay.' },
    { label: 'Expected recovery further along the route', minutes: recovery, detail: recovery < 0 ? 'The model expects some time to be recovered on later legs.' : 'No recovery is currently modeled.' }
  ];

  if(t.status === 'diverted'){
    factors.unshift({ label: 'Route diversion', minutes: delay, detail: 'The train is marked as diverted in the prototype data; the diversion may affect the predicted timing.' });
    factors = factors.slice(0, 4);
    // Preserve consistency: distribute the displayed total across the remaining rows.
    var rest = factors.slice(1);
    var restSum = rest.reduce(function(sum, f){ return sum + f.minutes; }, 0);
    factors[0].minutes = delay - restSum;
  }

  t.eta.factors = factors;

  var route = getRoutePoints(t);
  var nextIndex = -1;
  if(t.live.nextStation){
    nextIndex = route.findIndex(function(p){ return p.name === t.live.nextStation; });
  }
  if(nextIndex < 0) nextIndex = Math.min(1, Math.max(0, route.length - 1));

  // Generate a compact, always-available delay forecast for the next few
  // route checkpoints when a detailed schedule is not available.
  if(!t.stops || !t.stops.length || !t.eta.propagation || t.eta.propagation.length < 2){
    var points = route.slice(Math.max(0, nextIndex), Math.min(route.length, nextIndex + 4));
    if(points.length === 0 && route.length) points = [route[route.length - 1]];
    var baseDelay = delay;
    t.eta.propagation = points.map(function(point, idx){
      var ratio = points.length <= 1 ? 1 : idx / (points.length - 1);
      var pointDelay = Math.max(0, Math.round(baseDelay * (1 - 0.15 * ratio)));
      var scheduledTotal = clockMinutes(t.service.departure) + Math.round((route.indexOf(point) / Math.max(1, route.length - 1)) * t.service.durationMin);
      var predictedTotal = scheduledTotal + pointDelay;
      return {
        station: point.name,
        scheduled: formatClock(scheduledTotal),
        predicted: formatClock(predictedTotal),
        delayMin: pointDelay
      };
    });
  } else {
    // Keep the detailed 12951 propagation aligned with the current delay.
    t.eta.propagation = t.eta.propagation.map(function(p, idx){
      var pointDelay = delay > 0 ? Math.max(0, Math.round(delay - idx * Math.min(2, delay / 4))) : 0;
      return { station:p.station, scheduled:p.scheduled || p.scheduledArrival, predicted:p.predicted, delayMin:pointDelay };
    });
  }

  t.eta.explanationSummary = delay > 0
    ? ('Predicted arrival is about ' + delay + ' minute' + (delay === 1 ? '' : 's') + ' late based on current running delay, delay propagation, historical route patterns and modeled recovery.')
    : 'The train is currently on schedule; the ETA follows the timetable with no material delay modeled.';
  t.eta.inJourney = !!inJourney;
}

// ==========================================
// DATA ACCESS FUNCTIONS
// Every page calls these instead of reading the arrays
// directly — so swapping in a real API later only means
// changing the code inside these functions.
// ==========================================

function getTrain(trainNumber){
  for(var i = 0; i < GATI_TRAINS.length; i++){
    if(GATI_TRAINS[i].number === trainNumber){
      updateDynamicTrain(GATI_TRAINS[i]);
      return GATI_TRAINS[i];
    }
  }
  return null;
}

// Builds the ordered list of {name, coord} points a train's route
// line should pass through — the full stop-by-stop schedule when
// available, otherwise source + real intermediate junctions (see
// TRAIN_ROUTE_WAYPOINTS above) + destination, so every route bends
// along its genuine rail corridor instead of cutting a straight
// line between just two endpoints. Stations with no known
// coordinate are skipped.
function getRoutePoints(t){
  var names = [];
  if(t.stops && t.stops.length){
    names = t.stops.map(function(s){ return s.name; });
  } else {
    names.push(t.source);
    var waypoints = TRAIN_ROUTE_WAYPOINTS[t.number] || [];
    names = names.concat(waypoints);
    names.push(t.destination);
  }
  return names
    .map(function(name){ return { name: name, coord: STATION_COORDS[name] }; })
    .filter(function(p){ return !!p.coord; });
}

// ==========================================
// SMOOTH ROUTE CURVE
// Turns a handful of real station waypoints into a smooth,
// flowing curve that threads through every one of them —
// the way a real map (or Google Maps) draws a route along its
// actual path, instead of a route drawn as sharp-angled straight
// segments jumping from dot to dot. Uses a standard Catmull-Rom
// spline: no external plugin needed, and every original station
// coordinate still sits exactly on the curve.
// segmentsPerLeg controls how many interpolated points are added
// between each pair of real stations — higher is smoother.
// ==========================================
// Builds the geographic geometry used for the highlighted train line.
// Full timetable stops are still used for station markers/timeline, but a
// train can have additional corridor points so its line follows the actual
// railway corridor more closely. The line is deliberately NOT spline-smoothed:
// each segment is a straight geographic segment between real railway points,
// avoiding the artificial bowed curves that previously pulled routes away
// from the underlying railway network.
function getTrainLinePoints(t){
  var names = (t.routeWaypoints && t.routeWaypoints.length)
    ? t.routeWaypoints.slice()
    : null;
  if(names && names.length){
    return names
      .map(function(name){ return { name:name, coord:STATION_COORDS[name] }; })
      .filter(function(p){ return !!p.coord; });
  }
  return getRoutePoints(t);
}

function smoothRouteCurve(points, segmentsPerLeg){
  segmentsPerLeg = segmentsPerLeg || 14;
  if(points.length < 3) return points;

  // Centripetal Catmull-Rom (distance-based knot parameterization),
  // not the simpler uniform version. Uniform Catmull-Rom can
  // overshoot into loops or bulges whenever consecutive legs have
  // very different lengths — e.g. a short hop between two nearby
  // junctions followed by a long coast-hugging stretch, which is
  // exactly the demo-data pattern here and is what caused an
  // earlier version of this curve to bow out over open water on a
  // coastal route. The centripetal version stays much closer to
  // the straight path between real stations in that situation.
  var ALPHA = 0.5;
  var pts = [points[0]].concat(points).concat([points[points.length - 1]]);

  function dist(a, b){ var dx = a[0] - b[0], dy = a[1] - b[1]; return Math.sqrt(dx * dx + dy * dy); }
  function lerp2(pA, tA, pB, tB, t){
    var span = tB - tA;
    if(span === 0) return pA;
    var wB = (t - tA) / span, wA = (tB - t) / span;
    return [pA[0] * wA + pB[0] * wB, pA[1] * wA + pB[1] * wB];
  }

  var curve = [];
  for(var i = 0; i < pts.length - 3; i++){
    var p0 = pts[i], p1 = pts[i + 1], p2 = pts[i + 2], p3 = pts[i + 3];

    var t0 = 0;
    var t1 = t0 + (Math.pow(dist(p0, p1), ALPHA) || 1e-6);
    var t2 = t1 + (Math.pow(dist(p1, p2), ALPHA) || 1e-6);
    var t3 = t2 + (Math.pow(dist(p2, p3), ALPHA) || 1e-6);

    for(var s = 0; s < segmentsPerLeg; s++){
      var t = t1 + (t2 - t1) * (s / segmentsPerLeg);
      var A1 = lerp2(p0, t0, p1, t1, t);
      var A2 = lerp2(p1, t1, p2, t2, t);
      var A3 = lerp2(p2, t2, p3, t3, t);
      var B1 = lerp2(A1, t0, A2, t2, t);
      var B2 = lerp2(A2, t1, A3, t3, t);
      var C  = lerp2(B1, t1, B2, t2, t);
      curve.push(C);
    }
  }
  curve.push(points[points.length - 1]);
  return curve;
}

// Search by train number OR train name (case-insensitive, partial match).
function searchTrains(query){
  var source = GATI_TRAINS.map(function(t){ return updateDynamicTrain(t); });
  if(!query) return source;
  var q = query.trim().toLowerCase();
  return source.filter(function(t){
    return t.number.indexOf(q) !== -1 || t.name.toLowerCase().indexOf(q) !== -1;
  });
}

// ==========================================
// STATION ARRIVAL BOARDS (for the Live Station page)
// Live Station is derived from the same route source used by the
// Live Tracking > Route & Schedule timeline. This prevents the
// arrival board from inventing a different station membership list.
// A station is included only when its exact normalized name appears
// in the train route. No city substring matching is used.
// ==========================================
var GATI_STATION_ARRIVALS = {}; // Legacy placeholder; route data is authoritative.

function normalizeStationNameForRoute(value){
  return String(value == null ? '' : value)
    .toLowerCase()
    .replace(/[.']/g,'')
    .replace(/\s+/g,' ')
    .trim();
}

function getTrainRouteStationNames(t){
  // Use the raw route/timeline names rather than getRoutePoints(), because
  // getRoutePoints() intentionally drops stations that do not yet have a
  // coordinate in STATION_COORDS. Live Station must not turn a missing map
  // coordinate into a false "train not arriving" result.
  if(t.stops && t.stops.length){
    return t.stops.map(function(s){ return s.name; });
  }
  return [t.source].concat(TRAIN_ROUTE_WAYPOINTS[t.number] || []).concat([t.destination]);
}

function getScheduledStationTime(t, stationName){
  var target = normalizeStationNameForRoute(stationName);

  // Full timetable stops are authoritative when present.
  if(t.stops && t.stops.length){
    for(var i = 0; i < t.stops.length; i++){
      var stop = t.stops[i];
      if(normalizeStationNameForRoute(stop.name) === target){
        return {
          scheduled: stop.schedArr || stop.schedDep || '—',
          predicted: stop.actualArr || stop.schedArr || '—',
          kind: 'Scheduled stop'
        };
      }
    }
  }

  // Sparse prototype routes only have station-specific service times for
  // their origin/destination. Do not manufacture intermediate times.
  if(t.service){
    if(normalizeStationNameForRoute(t.source) === target){
      return { scheduled:t.service.departure || '—', predicted:'—', kind:'Origin' };
    }
    if(normalizeStationNameForRoute(t.destination) === target){
      return {
        scheduled:t.service.arrival || '—',
        predicted:t.eta && t.eta.predictedArrival ? t.eta.predictedArrival : '—',
        kind:'Destination'
      };
    }
  }

  return { scheduled:'—', predicted:'—', kind:'Route checkpoint' };
}

function getStationArrivals(stationName){
  var target = normalizeStationNameForRoute(stationName);
  if(!target || typeof GATI_TRAINS === 'undefined') return [];

  var out = [];
  var seen = {};

  GATI_TRAINS.forEach(function(t){
    var routeNames = getTrainRouteStationNames(t);
    var hit = routeNames.some(function(name){
      return normalizeStationNameForRoute(name) === target;
    });
    if(!hit) return;

    updateDynamicTrain(t);
    var timing = getScheduledStationTime(t, stationName);
    var key = t.number + '|' + target;
    if(seen[key]) return;
    seen[key] = true;

    out.push({
      number:t.number,
      name:t.name,
      scheduled:timing.scheduled,
      predicted:timing.predicted,
      delayMin:0,
      status:timing.kind,
      routeMatch:true,
      routeMatchKind:timing.kind
    });
  });

  return out;
}

// Delay -> badge class + label, used consistently everywhere
// a train's status is shown.
function delayStatusInfo(delayMin){
  var t = (typeof GatiI18n !== 'undefined') ? GatiI18n.t.bind(GatiI18n) : function(k){ return k; };
  if(delayMin === 0) return { cls: 'badge-ontime', label: t('status.onTime') };
  if(delayMin <= 15) return { cls: 'badge-delayed', label: t('status.delayed') + ' ' + delayMin + ' min' };
  return { cls: 'badge-majordelay', label: t('status.majorDelay') + ' ' + delayMin + ' min' };
}

// Cancelled/Rescheduled/Diverted are stored as lowercase status
// codes on the train object; this maps them to a translated label
// the same way everywhere they're shown as a badge.
function statusWordLabel(statusCode){
  var t = (typeof GatiI18n !== 'undefined') ? GatiI18n.t.bind(GatiI18n) : function(k){ return k; };
  var map = { cancelled: 'status.cancelled', rescheduled: 'status.rescheduled', diverted: 'status.diverted' };
  var key = map[statusCode];
  return key ? t(key) : (statusCode.charAt(0).toUpperCase() + statusCode.slice(1));
}
