/* ==========================================================
   MY TRAINS PAGE JAVASCRIPT (my-trains.html)
   ========================================================== */

function renderMyTrains(){
  var contentEl = document.getElementById('my-trains-content');
  var loginReqEl = document.getElementById('my-trains-login-required');
  var emptyEl = document.getElementById('my-trains-empty');

  if(!GatiAuth.isLoggedIn()){
    contentEl.innerHTML = '';
    loginReqEl.classList.remove('hidden');
    emptyEl.classList.add('hidden');
    return;
  }
  loginReqEl.classList.add('hidden');

  var numbers = GatiSaved.getAll();
  var trains = numbers.map(getTrain).filter(Boolean);

  if(!trains.length){
    contentEl.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  contentEl.innerHTML = trains.map(function(t){
    var status = delayStatusInfo(t.live.currentDelayMin);
    return (
      '<div class="saved-train-card">' +
        '<div>' +
          '<div class="name">' + t.number + ' ' + t.name + '</div>' +
          '<div class="route">' + t.source + ' → ' + t.destination + ' <span class="badge ' + status.cls + '">' + status.label + '</span></div>' +
        '</div>' +
        '<div class="predicted"><div class="l">Predicted arrival</div><div class="v">' + t.eta.predictedArrival + '</div></div>' +
        '<div class="actions">' +
          '<a href="tracking.html?train=' + t.number + '" class="btn btn-outline btn-sm">Track</a>' +
          '<button type="button" class="remove-btn" data-num="' + t.number + '" aria-label="Remove"><svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px;"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
        '</div>' +
      '</div>'
    );
  }).join('');

  contentEl.querySelectorAll('.remove-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      GatiSaved.remove(btn.getAttribute('data-num'));
      showToast('Removed from My Trains');
      renderMyTrains();
    });
  });
}

renderMyTrains();
