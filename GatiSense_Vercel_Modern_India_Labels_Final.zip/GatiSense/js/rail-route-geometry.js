/* ==========================================================
   GATISENSE — RAILWAY-ALIGNED TRAIN ROUTE GEOMETRY
   ----------------------------------------------------------
   Uses the same OSM-derived Indian railway polyline network already
   displayed underneath the GatiSense route. For each train-route leg,
   it queries a narrow corridor of that network and traces a connected
   path between the two station points.

   This is deliberately asynchronous and fail-soft:
   - Accurate railway geometry is preferred.
   - If the public feature service is unavailable, the existing station
     corridor is used as a safe fallback.
   - Results are cached in memory for the current page session.

   The service is a polyline railway network, not a road-routing service.
   That keeps the highlighted train route on railway infrastructure rather
   than drawing a road-like or straight-line path.
   ========================================================== */

var GATI_RAIL_ROUTE_CACHE = Object.create(null);
var GATI_RAIL_ROUTE_PENDING = Object.create(null);

var GATI_RAIL_NETWORK_QUERY_URL = 'https://livingatlas.esri.in/server/rest/services/OSM/Railways/MapServer/0/query';

function gatiRouteCoordKey(coord){
  return Number(coord[0]).toFixed(5) + ',' + Number(coord[1]).toFixed(5);
}

function gatiGeoDistanceKm(a, b){
  var R = 6371;
  var dLat = (b[1] - a[1]) * Math.PI / 180;
  var dLon = (b[0] - a[0]) * Math.PI / 180;
  var lat1 = a[1] * Math.PI / 180;
  var lat2 = b[1] * Math.PI / 180;
  var s = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon/2) * Math.sin(dLon/2);
  return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(Math.max(0, 1-s)));
}

function gatiPointSegmentDistanceKm(p, a, b){
  var latScale = 111.32;
  var lonScale = 111.32 * Math.cos(((a[1] + b[1] + p[1]) / 3) * Math.PI / 180);
  var px = p[0] * lonScale, py = p[1] * latScale;
  var ax = a[0] * lonScale, ay = a[1] * latScale;
  var bx = b[0] * lonScale, by = b[1] * latScale;
  var dx = bx - ax, dy = by - ay;
  var len2 = dx*dx + dy*dy;
  var t = len2 ? ((px-ax)*dx + (py-ay)*dy) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  var cx = ax + t*dx, cy = ay + t*dy;
  return Math.sqrt((px-cx)*(px-cx) + (py-cy)*(py-cy));
}

function gatiRailFeatureCoordinates(feature){
  if(!feature || !feature.geometry) return [];
  var g = feature.geometry;
  if(g.type === 'LineString') return [g.coordinates];
  if(g.type === 'MultiLineString') return g.coordinates || [];
  return [];
}

function gatiRouteEnvelope(a, b, padDeg){
  return {
    xmin: Math.min(a[0], b[0]) - padDeg,
    ymin: Math.min(a[1], b[1]) - padDeg,
    xmax: Math.max(a[0], b[0]) + padDeg,
    ymax: Math.max(a[1], b[1]) + padDeg
  };
}

function gatiQueryRailNetwork(a, b){
  var distance = gatiGeoDistanceKm(a, b);
  /* Wider corridors for long intercity legs, but never so wide that an
     entire state becomes the routing graph. */
  var pad = Math.max(0.12, Math.min(0.55, 0.10 + distance * 0.018));
  var e = gatiRouteEnvelope(a, b, pad);
  var params = new URLSearchParams({
    where: "country = 'India'",
    geometry: [e.xmin, e.ymin, e.xmax, e.ymax].join(','),
    geometryType: 'esriGeometryEnvelope',
    inSR: '4326',
    spatialRel: 'esriSpatialRelIntersects',
    outFields: 'objectid,fname,fclass,ref_code,country',
    returnGeometry: 'true',
    outSR: '4326',
    f: 'geojson',
    resultRecordCount: '2000'
  });

  return fetch(GATI_RAIL_NETWORK_QUERY_URL + '?' + params.toString(), {
    method: 'GET',
    mode: 'cors',
    credentials: 'omit'
  }).then(function(res){
    if(!res.ok) throw new Error('Rail network query HTTP ' + res.status);
    return res.json();
  }).then(function(json){
    if(!json || !Array.isArray(json.features)) throw new Error('Invalid rail network response');
    return json.features;
  });
}

function gatiBuildRailGraph(features, start, end){
  var nodes = Object.create(null);
  var buckets = Object.create(null);
  var edges = Object.create(null);

  function addNode(coord){
    var key = gatiRouteCoordKey(coord);
    if(!nodes[key]){
      nodes[key] = { key:key, coord:[Number(coord[0]), Number(coord[1])], edges:[] };
      var parts = key.split(',');
      var bx = Math.round(Number(parts[0]) * 1000);
      var by = Math.round(Number(parts[1]) * 1000);
      var bk = bx + ':' + by;
      if(!buckets[bk]) buckets[bk] = [];
      buckets[bk].push(key);
    }
    return key;
  }

  function addEdge(aKey, bKey, corridorA, corridorB){
    if(aKey === bKey) return;
    var a = nodes[aKey].coord, b = nodes[bKey].coord;
    var length = gatiGeoDistanceKm(a,b);
    if(!isFinite(length) || length <= 0.00001 || length > 15) return;
    var mid = [(a[0]+b[0])/2, (a[1]+b[1])/2];
    var corridorPenalty = gatiPointSegmentDistanceKm(mid, corridorA, corridorB);
    /* Keep the graph near the requested intercity corridor, but do not
       punish legitimate railway detours so heavily that a false shortcut
       branch becomes preferable. */
    var cost = length * (1 + Math.min(1.2, corridorPenalty / 40));
    var k = aKey < bKey ? aKey + '|' + bKey : bKey + '|' + aKey;
    if(edges[k] && edges[k].cost <= cost) return;
    edges[k] = {a:aKey,b:bKey,cost:cost};
  }

  features.forEach(function(feature){
    gatiRailFeatureCoordinates(feature).forEach(function(line){
      if(!line || line.length < 2) return;
      var prev = addNode(line[0]);
      for(var i=1;i<line.length;i++){
        var cur = addNode(line[i]);
        /* Keep the network topology exactly as supplied by the service. */
        addEdge(prev, cur, start, end);
        prev = cur;
      }
    });
  });

  /* Snap disconnected OSM/Esri segments that terminate within ~70m. */
  var nodeKeys = Object.keys(nodes);
  var maxSnapKm = 0.075;
  nodeKeys.forEach(function(key){
    var n = nodes[key];
    var bx = Math.round(n.coord[0]*1000), by = Math.round(n.coord[1]*1000);
    for(var dx=-1;dx<=1;dx++){
      for(var dy=-1;dy<=1;dy++){
        var list = buckets[(bx+dx)+':'+(by+dy)] || [];
        list.forEach(function(otherKey){
          if(otherKey === key) return;
          var other = nodes[otherKey];
          if(gatiGeoDistanceKm(n.coord, other.coord) <= maxSnapKm){
            addEdge(key, otherKey, start, end);
          }
        });
      }
    }
  });

  Object.keys(edges).forEach(function(k){
    var e = edges[k];
    nodes[e.a].edges.push({to:e.b,cost:e.cost});
    nodes[e.b].edges.push({to:e.a,cost:e.cost});
  });

  function nearestNode(coord){
    var best = null, bestD = Infinity;
    nodeKeys.forEach(function(key){
      var d = gatiGeoDistanceKm(coord, nodes[key].coord);
      if(d < bestD){ bestD=d; best=key; }
    });
    return {key:best,distance:bestD};
  }

  var s = nearestNode(start), t = nearestNode(end);
  if(!s.key || !t.key || s.distance > 8 || t.distance > 8) return null;

  /* Dijkstra with a small graph; a binary heap is unnecessary at this scale. */
  var dist = Object.create(null), prev = Object.create(null), open = Object.create(null);
  dist[s.key] = 0; open[s.key] = true;
  while(Object.keys(open).length){
    var current = null, currentD = Infinity;
    Object.keys(open).forEach(function(k){
      if((dist[k] == null ? Infinity : dist[k]) < currentD){ currentD = dist[k]; current=k; }
    });
    if(!current) break;
    delete open[current];
    if(current === t.key) break;
    nodes[current].edges.forEach(function(edge){
      var nd = currentD + edge.cost;
      if(dist[edge.to] == null || nd < dist[edge.to]){
        dist[edge.to] = nd;
        prev[edge.to] = current;
        open[edge.to] = true;
      }
    });
  }
  if(dist[t.key] == null) return null;

  var path = [], cur = t.key;
  while(cur){
    path.push(nodes[cur].coord);
    if(cur === s.key) break;
    cur = prev[cur];
  }
  path.reverse();
  return path;
}

function gatiDedupeRoute(points){
  var out = [];
  points.forEach(function(p){
    if(!p) return;
    if(!out.length || gatiGeoDistanceKm(out[out.length-1], p) > 0.01) out.push(p);
  });
  return out;
}

function getAccurateTrainRoute(t){
  if(!t) return Promise.resolve([]);
  var cacheKey = String(t.number);
  if(GATI_RAIL_ROUTE_CACHE[cacheKey]) return Promise.resolve(GATI_RAIL_ROUTE_CACHE[cacheKey]);
  if(GATI_RAIL_ROUTE_PENDING[cacheKey]) return GATI_RAIL_ROUTE_PENDING[cacheKey];

  var base = getTrainLinePoints(t).map(function(p){ return p.coord; });
  if(base.length < 2) return Promise.resolve(base);

  var promise = Promise.resolve().then(function(){
    var legs = [];
    for(var i=0;i<base.length-1;i++) legs.push([base[i], base[i+1]]);
    /* Query legs in parallel so a long train route does not wait for one
       HTTP request after another. The final concatenation still preserves
       the train's station order. */
    return Promise.all(legs.map(function(leg){
      return gatiQueryRailNetwork(leg[0], leg[1]).then(function(features){
        var path = gatiBuildRailGraph(features, leg[0], leg[1]);
        return (path && path.length >= 2) ? path : [leg[0], leg[1]];
      }).catch(function(){
        return [leg[0], leg[1]];
      });
    })).then(function(paths){
      var all = [];
      paths.forEach(function(path){
        if(!path || !path.length) return;
        if(all.length) path = path.slice(1);
        all = all.concat(path);
      });
      return all;
    });
  }).then(function(route){
    route = gatiDedupeRoute(route);
    GATI_RAIL_ROUTE_CACHE[cacheKey] = route;
    delete GATI_RAIL_ROUTE_PENDING[cacheKey];
    return route;
  }).catch(function(){
    delete GATI_RAIL_ROUTE_PENDING[cacheKey];
    GATI_RAIL_ROUTE_CACHE[cacheKey] = base;
    return base;
  });

  GATI_RAIL_ROUTE_PENDING[cacheKey] = promise;
  return promise;
}
