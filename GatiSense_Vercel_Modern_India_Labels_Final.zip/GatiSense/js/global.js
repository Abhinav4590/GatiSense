/* ==========================================================
   GATISENSE — GLOBAL JAVASCRIPT
   Shared behavior used on every page:
     - Mobile navigation menu
     - Auth state (persisted across pages for the prototype)
     - Toast helper
   Page-specific logic (search, tracking, eta, etc.) lives in
   that page's own JS file, not here.
   ========================================================== */

// ==========================================
// MOBILE NAVIGATION MENU
// ==========================================
function initMobileNav(){
  var btn = document.getElementById('hamburger-btn');
  var nav = document.getElementById('main-nav');
  if(!btn || !nav) return;
  btn.addEventListener('click', function(){
    nav.classList.toggle('mobile-open');
  });
}

// ==========================================
// AUTH STATE
// For this prototype, "login" is simulated and stored in
// localStorage so it persists as you move between the
// separate HTML pages. A real build would replace this with
// a FastAPI session / token check instead.
// ==========================================
var GatiAuth = {
  KEY: 'gatisense_demo_user',

  isLoggedIn: function(){
    return !!localStorage.getItem(this.KEY);
  },

  getName: function(){
    return localStorage.getItem(this.KEY) || '';
  },

  login: function(name){
    localStorage.setItem(this.KEY, name || 'Guest');
  },

  logout: function(){
    localStorage.removeItem(this.KEY);
  }
};

// Renders the header's account area based on current auth state.
// Every page includes a <div id="header-account-slot"></div> in
// its header markup; this fills it in.
// Logged-in state is a clickable dropdown (avatar + caret) with
// "My Trains" and "Log out" — not just a plain link — so there's
// an actual way to log back out.
function renderHeaderAccount(){
  var slot = document.getElementById('header-account-slot');
  if(!slot) return;

  if(GatiAuth.isLoggedIn()){
    var name = GatiAuth.getName();
    var initial = name.charAt(0).toUpperCase();
    slot.innerHTML =
      '<div class="header-account-menu">' +
        '<button type="button" class="header-account" id="header-account-btn" aria-haspopup="true" aria-expanded="false">' +
          '<span class="avatar-circle">' + initial + '</span>' +
          '<span>' + name + '</span>' +
          '<svg class="icon caret" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>' +
        '</button>' +
        '<div class="account-dropdown" id="account-dropdown" hidden>' +
          '<a href="my-trains.html" data-i18n="account.myTrains">' + GatiI18n.t('account.myTrains') + '</a>' +
          '<button type="button" id="account-logout-btn" data-i18n="account.logout">' + GatiI18n.t('account.logout') + '</button>' +
        '</div>' +
      '</div>';

    var toggleBtn = document.getElementById('header-account-btn');
    var dropdown = document.getElementById('account-dropdown');
    var logoutBtn = document.getElementById('account-logout-btn');

    toggleBtn.addEventListener('click', function(e){
      e.stopPropagation();
      var isOpen = !dropdown.hidden;
      dropdown.hidden = isOpen;
      toggleBtn.setAttribute('aria-expanded', String(!isOpen));
    });

    logoutBtn.addEventListener('click', function(){
      GatiAuth.logout();
      showToast(GatiI18n.t('account.loggedOut'));
      setTimeout(function(){ window.location.reload(); }, 500);
    });
  } else {
    slot.innerHTML = '<a href="login.html" class="header-text-link" data-i18n="account.login">' + GatiI18n.t('account.login') + '</a>';
  }
}

// Close the account dropdown on any click outside it, or on Escape.
document.addEventListener('click', function(e){
  var dropdown = document.getElementById('account-dropdown');
  var btn = document.getElementById('header-account-btn');
  if(!dropdown || dropdown.hidden) return;
  if(e.target === btn || (btn && btn.contains(e.target))) return;
  if(dropdown.contains(e.target)) return;
  dropdown.hidden = true;
  if(btn) btn.setAttribute('aria-expanded', 'false');
});
document.addEventListener('keydown', function(e){
  if(e.key !== 'Escape') return;
  var dropdown = document.getElementById('account-dropdown');
  var btn = document.getElementById('header-account-btn');
  if(dropdown && !dropdown.hidden){
    dropdown.hidden = true;
    if(btn) btn.setAttribute('aria-expanded', 'false');
  }
});

// ==========================================
// LANGUAGE (EN / हिंदी)
// Same persistence pattern as GatiAuth: stored in localStorage
// so the chosen language sticks as you move between pages.
// Static text uses data-i18n="key" attributes, translated via
// GatiI18n.apply(). Dynamic strings that pages generate in JS
// (status badges, etc.) call GatiI18n.t('key') directly and
// re-render on the 'gati:langchange' event.
// ==========================================
var GATI_I18N_DICT = {
  en: {
    'nav.home': 'Home', 'nav.search': 'Search Train', 'nav.tracking': 'Live Tracking',
    'nav.eta': 'ETA Prediction', 'nav.station': 'Live Station', 'nav.map': 'Railway Map',
    'nav.alerts': 'Alerts',
    'account.login': 'Login', 'account.myTrains': 'My Trains', 'account.logout': 'Log out',
    'account.loggedOut': 'Logged out',
    'footer.tagline': 'Dynamic train tracking and ETA prediction prototype.',
    'status.onTime': 'On time', 'status.delayed': 'Delayed', 'status.majorDelay': 'Major delay',
    'status.cancelled': 'Cancelled', 'status.rescheduled': 'Rescheduled', 'status.diverted': 'Diverted',
    'status.departed': 'Departed', 'status.current': 'Current', 'status.upcoming': 'Upcoming'
  },
  hi: {
    'nav.home': 'होम', 'nav.search': 'ट्रेन खोजें', 'nav.tracking': 'लाइव ट्रैकिंग',
    'nav.eta': 'ईटीए पूर्वानुमान', 'nav.station': 'लाइव स्टेशन', 'nav.map': 'रेलवे मानचित्र',
    'nav.alerts': 'अलर्ट',
    'account.login': 'लॉगिन', 'account.myTrains': 'मेरी ट्रेनें', 'account.logout': 'लॉग आउट',
    'account.loggedOut': 'लॉग आउट हो गए',
    'footer.tagline': 'डायनामिक ट्रेन ट्रैकिंग और ईटीए पूर्वानुमान प्रोटोटाइप।',
    'status.onTime': 'समय पर', 'status.delayed': 'देरी', 'status.majorDelay': 'बड़ी देरी',
    'status.cancelled': 'रद्द', 'status.rescheduled': 'पुनर्निर्धारित', 'status.diverted': 'मार्ग परिवर्तित',
    'status.departed': 'रवाना', 'status.current': 'वर्तमान', 'status.upcoming': 'आगामी'
  }
};

var GatiI18n = {
  KEY: 'gatisense_lang',

  getLang: function(){
    return localStorage.getItem(this.KEY) || 'en';
  },

  setLang: function(lang){
    localStorage.setItem(this.KEY, lang);
    document.documentElement.setAttribute('lang', lang);
    this.apply();
    window.dispatchEvent(new CustomEvent('gati:langchange', { detail: { lang: lang } }));
  },

  // Looks up key in the current language, falling back to English,
  // then to the key itself, so untranslated strings never break.
  t: function(key){
    var lang = this.getLang();
    var dict = GATI_I18N_DICT[lang] || GATI_I18N_DICT.en;
    return dict[key] || GATI_I18N_DICT.en[key] || key;
  },

  // Fills every element with a data-i18n attribute.
  apply: function(){
    var self = this;
    document.querySelectorAll('[data-i18n]').forEach(function(el){
      el.textContent = self.t(el.getAttribute('data-i18n'));
    });
    document.querySelectorAll('.lang-toggle button').forEach(function(btn, i){
      btn.classList.toggle('active', (i === 0 && self.getLang() === 'en') || (i === 1 && self.getLang() === 'hi'));
    });
  }
};

function initLangToggle(){
  document.documentElement.setAttribute('lang', GatiI18n.getLang());
  document.querySelectorAll('.lang-toggle').forEach(function(toggle){
    var buttons = toggle.querySelectorAll('button');
    if(buttons.length < 2) return;
    buttons[0].addEventListener('click', function(){ GatiI18n.setLang('en'); });
    buttons[1].addEventListener('click', function(){ GatiI18n.setLang('hi'); });
  });
  GatiI18n.apply();
}

// ==========================================
// SAVED TRAINS (My Trains)
// Shared by the Save button on Tracking, and the My Trains and
// Notifications pages, so the list logic lives in one place.
// ==========================================
var GatiSaved = {
  KEY: 'gatisense_saved_trains',

  getAll: function(){
    try{ return JSON.parse(localStorage.getItem(this.KEY)) || []; }
    catch(e){ return []; }
  },
  isSaved: function(number){
    return this.getAll().indexOf(number) !== -1;
  },
  add: function(number){
    var list = this.getAll();
    if(list.indexOf(number) === -1) list.push(number);
    localStorage.setItem(this.KEY, JSON.stringify(list));
  },
  remove: function(number){
    var list = this.getAll().filter(function(n){ return n !== number; });
    localStorage.setItem(this.KEY, JSON.stringify(list));
  }
};

// ==========================================
// TOAST HELPER
// Small non-blocking confirmation message, used across pages
// (e.g. "Train saved", "Alert enabled").
// ==========================================
var _toastTimer;
function showToast(message){
  var toast = document.getElementById('toast');
  if(!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(function(){ toast.classList.remove('show'); }, 2600);
}

// ==========================================
// INIT — runs on every page once the DOM is ready
// ==========================================
document.addEventListener('DOMContentLoaded', function(){
  initMobileNav();
  renderHeaderAccount();
  initLangToggle();
});

// Re-render the account chrome when the language changes, since it
// has translated text baked into innerHTML rather than data-i18n
// (the avatar name itself isn't translatable, so it's rebuilt here).
window.addEventListener('gati:langchange', function(){
  renderHeaderAccount();
});
