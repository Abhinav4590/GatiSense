/* ==========================================================
   NOTIFICATIONS PAGE JAVASCRIPT (notifications.html)
   Notifications are built from each saved train's real data
   (its actual ETA history and current delay) rather than
   invented text, so they stay consistent with what Tracking
   and ETA Prediction show for the same train.
   ========================================================== */

function buildNotifications(){
  var trains = GatiSaved.getAll().map(getTrain).filter(Boolean);
  var items = [];

  trains.forEach(function(t){
    // ETA update notification, from the train's real ETA history.
    if(t.eta.history && t.eta.history.length > 1){
      var prev = t.eta.history[t.eta.history.length - 2];
      var latest = t.eta.history[t.eta.history.length - 1];
      items.push({
        type: 'eta',
        title: 'ETA Updated',
        detail: t.number + ' ' + t.name + ' predicted arrival changed from ' + prev.eta + ' to ' + latest.eta + '.',
        time: latest.time,
        group: 'Today'
      });
    }
    // Delay notification, from the train's real current delay.
    if(t.live.currentDelayMin > 0){
      items.push({
        type: 'delay',
        title: 'Delay Alert',
        detail: t.number + ' ' + t.name + ' is currently ' + t.live.currentDelayMin + ' minutes late.',
        time: t.live.lastUpdatedMinsAgo + ' min ago',
        group: 'Today'
      });
    }
    // Status notification, for cancelled/rescheduled/diverted trains.
    if(t.status === 'cancelled' || t.status === 'rescheduled' || t.status === 'diverted'){
      var label = statusWordLabel(t.status);
      items.push({
        type: 'status',
        title: 'Train ' + label,
        detail: t.number + ' ' + t.name + ' — ' + label.toLowerCase() + '. Check Live Tracking for details.',
        time: 'Today',
        group: 'Today'
      });
    }
  });

  return items;
}

function renderNotifications(){
  var contentEl = document.getElementById('notifications-content');
  var loginReqEl = document.getElementById('notifications-login-required');
  var emptyEl = document.getElementById('notifications-empty');

  if(!GatiAuth.isLoggedIn()){
    contentEl.innerHTML = '';
    loginReqEl.classList.remove('hidden');
    emptyEl.classList.add('hidden');
    return;
  }
  loginReqEl.classList.add('hidden');

  var items = buildNotifications();
  if(!items.length){
    contentEl.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  var iconPaths = {
    eta: '<path d="M12 3a6 6 0 0 0-3 11.2V16h6v-1.8A6 6 0 0 0 12 3z"/>',
    delay: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
    status: '<path d="M12 9v4M12 17h.01"/><circle cx="12" cy="12" r="9"/>'
  };

  contentEl.innerHTML =
    '<div class="notif-group-label">Today</div>' +
    items.map(function(n){
      return (
        '<div class="notif-item">' +
          '<div class="notif-icon ' + n.type + '"><svg class="icon" viewBox="0 0 24 24">' + iconPaths[n.type] + '</svg></div>' +
          '<div class="notif-body"><div class="t">' + n.title + '</div><div class="d">' + n.detail + '</div></div>' +
          '<div class="notif-time">' + n.time + '</div>' +
        '</div>'
      );
    }).join('');
}

renderNotifications();
