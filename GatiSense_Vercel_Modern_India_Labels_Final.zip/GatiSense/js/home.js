/* ==========================================================
   HOME PAGE JAVASCRIPT (index.html)
   ========================================================== */

// ==========================================
// TRAIN SEARCH / TRACK FORM
// Sends the entered train number or name to the Search page.
// ==========================================
document.getElementById('track-form').addEventListener('submit', function(e){
  e.preventDefault();
  var q = document.getElementById('track-input').value.trim();
  window.location.href = 'search.html' + (q ? ('?q=' + encodeURIComponent(q)) : '');
});

// Quick example buttons fill the field and submit straight away.
document.querySelectorAll('.chip-link').forEach(function(btn){
  btn.addEventListener('click', function(){
    window.location.href = 'search.html?q=' + encodeURIComponent(btn.getAttribute('data-ex'));
  });
});

// ==========================================
// RAILWAY NETWORK STATUS
// A calm passenger-facing overview, not a control-room
// dashboard — just four simple counts.
// ==========================================
(function renderNetworkStatus(){
  var onTime = GATI_TRAINS.filter(function(t){ return t.live.currentDelayMin === 0; }).length;
  var delayed = GATI_TRAINS.filter(function(t){ return t.live.currentDelayMin > 0 && t.live.currentDelayMin <= 15; }).length;
  var major = GATI_TRAINS.filter(function(t){ return t.live.currentDelayMin > 15; }).length;

  var tiles = [
    { n: GATI_TRAINS.length + ',248', l: 'Trains monitored' },
    { n: String(onTime), l: 'On time now' },
    { n: String(delayed), l: 'Delayed' },
    { n: String(major), l: 'Major delays' }
  ];

  var grid = document.getElementById('status-grid');
  grid.innerHTML = tiles.map(function(t){
    return '<div class="status-item"><div class="n">' + t.n + '</div><div class="l">' + t.l + '</div></div>';
  }).join('');
})();
