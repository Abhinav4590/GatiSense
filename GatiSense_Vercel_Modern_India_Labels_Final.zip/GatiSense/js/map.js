/* ==========================================================
   RAILWAY MAP PAGE JAVASCRIPT (map.html)
   GatiSense railway map using an OSM-derived line-only railway network
   plus the existing Indian railway GIS network, with GatiSense live
   routes and train markers drawn above them.
   ========================================================== */

var railMap = L.map('railway-map', {
  preferCanvas: true,
  scrollWheelZoom: true,
  minZoom: 4,
  maxZoom: 15,
  zoomControl: true,
  zoomAnimation: true,
  fadeAnimation: true,
  zoomAnimationThreshold: 4,
  attributionControl: true
}).setView([22.9734, 78.6569], 5);

/* ==========================================
   CLEAN MAP BASE
   ========================================== */
var baseLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
  maxZoom: 19,
  updateWhenIdle: true,
  updateWhenZooming: false,
  keepBuffer: 1,
  attribution: '&copy; Esri, DeLorme, NAVTEQ'
}).addTo(railMap);

/* ==========================================
   SHARED OSM RAILWAY NETWORK + INDIA BOUNDARY
   The railway network is rendered from OpenStreetMap railway
   polylines plus the existing Indian railway GIS. The India boundary
   is the supplied GatiSense geometry and is drawn above the railway
   network as a black outline only.
   ========================================== */
var indiaMapLayers = addGatiIndiaMapLayers(railMap, {
  railwayOpacity: 0.95,
  boundaryWeight: 1.0
});

var stationMarkers = {};
var trainLayers = [];
var currentMapFilter = 'all';

/* ==========================================
   GATISENSE BACKGROUND CORRIDOR GUIDE
   ========================================== */
RAIL_CORRIDORS.forEach(function(routeNames){
  var pts = routeNames.map(function(n){ return STATION_COORDS[n]; }).filter(Boolean);
  if(pts.length > 1){
    L.polyline(pts, {
      color: '#9AA3AF', weight: 1.2, opacity: 0.25,
      dashArray: '2 7', interactive: false
    }).addTo(railMap);
  }
});

/* ==========================================
   STATION MARKERS
   ========================================== */
var activeStationNames = {};
GATI_TRAINS.forEach(function(t){
  getRoutePoints(t).forEach(function(p){ activeStationNames[p.name] = true; });
});

/* ==========================================================
   EARLY STATION LABELS
   GatiSense adds lightweight station-name
   labels at medium zoom without replacing the OSM railway layer.
   At zoom 7 only stations used by the live/demo routes are shown;
   at zoom 8+ the complete GatiSense station list is shown.
   ========================================================== */
var stationLabelPane = railMap.createPane('gatiStationLabelPane');
stationLabelPane.style.zIndex = 610;
stationLabelPane.style.pointerEvents = 'none';
var stationLabelMarkers = {};
var stationLabelZoom = 7;

function stationLabelIcon(name){
  return L.divIcon({
    className: 'gati-station-label',
    html: '<span>' + name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</span>',
    iconSize: null,
    iconAnchor: [0, 0]
  });
}

Object.keys(STATION_COORDS).forEach(function(name){
  stationLabelMarkers[name] = L.marker(STATION_COORDS[name], {
    icon: stationLabelIcon(name),
    interactive: false,
    keyboard: false,
    pane: 'gatiStationLabelPane',
    zIndexOffset: -100
  });
});

function syncStationLabels(){
  var z = railMap.getZoom();
  Object.keys(stationLabelMarkers).forEach(function(name){
    var shouldShow = z >= stationLabelZoom && (z >= 8 || !!activeStationNames[name]);
    var marker = stationLabelMarkers[name];
    if(shouldShow){
      if(!railMap.hasLayer(marker)) marker.addTo(railMap);
    } else if(railMap.hasLayer(marker)){
      railMap.removeLayer(marker);
    }
  });
}

railMap.on('zoomend', syncStationLabels);

Object.keys(STATION_COORDS).forEach(function(name){
  var coord = STATION_COORDS[name];
  var isActive = !!activeStationNames[name];
  var icon = L.divIcon({
    className: 'gati-station-dot',
    html: '<div style="width:' + (isActive ? 10 : 7) + 'px;height:' + (isActive ? 10 : 7) + 'px;border-radius:50%;background:' + (isActive ? '#182644' : '#ffffff') + ';border:2px solid ' + (isActive ? '#ffffff' : '#6F7785') + ';box-shadow:0 0 0 1px ' + (isActive ? '#182644' : '#6F7785') + ';"></div>',
    iconSize: [12, 12],
    iconAnchor: [6, 6]
  });
  var marker = L.marker(coord, { icon: icon }).addTo(railMap).bindPopup('<b>' + name + '</b>');
  stationMarkers[name] = marker;
});

syncStationLabels();

/* ==========================================
   GATISENSE LIVE TRAIN ROUTES
   ========================================== */
function bucketFor(t){
  if(t.live.currentDelayMin === 0) return 'ontime';
  if(t.live.currentDelayMin <= 15) return 'delayed';
  return 'major';
}

GATI_TRAINS.forEach(function(t){
  /* Refresh the prototype running snapshot before placing a train marker.
     This prevents scheduled/completed trains from being shown at an arbitrary
     fallback waypoint. */
  if(typeof updateDynamicTrain === 'function') updateDynamicTrain(t);
  var bucket = bucketFor(t);
  var routeColor = bucket === 'ontime' ? '#16804B' : (bucket === 'delayed' ? '#8B5A3C' : '#C43A3A');
  var routePoints = getTrainLinePoints(t).map(function(p){ return p.coord; });
  if(routePoints.length < 2) return;

  var group = L.layerGroup().addTo(railMap);
  // Straight geographic segments between actual railway points. Keeping the
  // line unsmoothed makes it visually precise and prevents artificial curves
  // from drifting away from the orange railway infrastructure underneath.
  var lineCasing = L.polyline(routePoints, {
    color: '#FFFFFF',
    weight: 9,
    opacity: 0.86,
    lineCap: 'round',
    lineJoin: 'round',
    interactive: false,
    className: 'gati-live-route-casing'
  }).addTo(group);
  var line = L.polyline(routePoints, {
    color: routeColor,
    weight: 5,
    opacity: 0.97,
    lineCap: 'round',
    lineJoin: 'round',
    className: 'gati-live-route'
  }).addTo(group);
  line.on('click', function(){
    showTrainDetail(t);
    if(typeof getAccurateTrainRoute === 'function'){
      getAccurateTrainRoute(t).then(function(accurateRoute){
        if(!accurateRoute || accurateRoute.length < 2) return;
        line.setLatLngs(accurateRoute);
        lineCasing.setLatLngs(accurateRoute);
        /* Keep the selected route visually aligned to the real railway
           geometry without querying every train during initial page load. */
        railMap.fitBounds(L.latLngBounds(accurateRoute), { padding: [30, 30], maxZoom: 8 });
      });
    }
  });

  /*
     IMPORTANT: these are TRAIN positions, not station dots.
     The old implementation used an animated HTML divIcon with a pulsing
     CSS transform and, when currentPosition was missing, silently placed the
     train at an arbitrary route waypoint. That made the large rings look like
     floating/drifting map points and also produced false train positions.

     A Leaflet geographic circle is used instead. Its center is the actual
     latitude/longitude and Leaflet's renderer keeps that point geographically
     anchored through pan/zoom. There is deliberately no CSS pulse animation.
  */
  var marker = null;
  var currentPos = t.live.currentPosition;
  if(Array.isArray(currentPos) && currentPos.length === 2 &&
     Number.isFinite(Number(currentPos[0])) && Number.isFinite(Number(currentPos[1]))){
    var trainStatusClass = bucket === 'ontime' ? 'on-time' : (bucket === 'delayed' ? 'delayed' : 'major');
    var trainIcon = L.divIcon({
      className: 'gati-current-train-icon',
      html: '<div class="gati-current-train ' + trainStatusClass + '" aria-label="Current train position"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3.5" width="14" height="14" rx="3"/><path d="M8 17.5l-1.5 3M16 17.5l1.5 3M8 8h8M9 12h.01M15 12h.01"/></svg></div>',
      iconSize: [30, 30],
      iconAnchor: [15, 15]
    });
    marker = L.marker(currentPos, {
      icon: trainIcon,
      keyboard: false,
      zIndexOffset: 500,
      riseOnHover: true
    }).addTo(group)
      .bindPopup('<b>' + t.number + ' ' + t.name + '</b><br>' + t.source + ' → ' + t.destination + '<br>' + delayStatusInfo(t.live.currentDelayMin).label);
    marker.on('click', function(){ showTrainDetail(t); });
  }

  trainLayers.push({ number: t.number, bucket: bucket, layerGroup: group, marker: marker });
});

/* ==========================================
   FILTERS
   ========================================== */
function applyMapFilter(){
  trainLayers.forEach(function(entry){
    var shouldShow = currentMapFilter === 'all' || entry.bucket === currentMapFilter;
    if(shouldShow){
      if(!railMap.hasLayer(entry.layerGroup)) entry.layerGroup.addTo(railMap);
    } else if(railMap.hasLayer(entry.layerGroup)) {
      railMap.removeLayer(entry.layerGroup);
    }
  });
}

var filterPillsEl = document.getElementById('map-filter-pills');
if(filterPillsEl){
  filterPillsEl.querySelectorAll('.filter-pill').forEach(function(pill){
    pill.addEventListener('click', function(){
      filterPillsEl.querySelectorAll('.filter-pill').forEach(function(p){ p.classList.remove('active'); });
      pill.classList.add('active');
      currentMapFilter = pill.getAttribute('data-filter');
      applyMapFilter();
    });
  });
}

/* ==========================================
   SELECTED TRAIN DETAIL PANEL
   ========================================== */
function showTrainDetail(t){
  var emptyEl = document.getElementById('mdp-empty');
  var contentEl = document.getElementById('mdp-content');
  if(!emptyEl || !contentEl) return;

  var status = delayStatusInfo(t.live.currentDelayMin);
  var isIssue = t.status === 'cancelled' || t.status === 'rescheduled' || t.status === 'diverted';
  var badgeCls = isIssue ? 'badge-neutral' : status.cls;
  var badgeLabel = isIssue ? statusWordLabel(t.status) : status.label;

  contentEl.innerHTML =
    '<div class="mdp-num">' + t.number + '</div>' +
    '<div class="mdp-name">' + t.name + '</div>' +
    '<div class="mdp-route">' + t.source + ' → ' + t.destination + '</div>' +
    '<span class="badge ' + badgeCls + '">' + badgeLabel + '</span>' +
    '<div class="mdp-row"><span class="l">Current location</span><span class="v">' + t.live.currentLocationText + '</span></div>' +
    '<div class="mdp-row"><span class="l">Next station</span><span class="v">' + (t.live.nextStation || '—') + '</span></div>' +
    '<div class="mdp-row"><span class="l">Predicted arrival</span><span class="v">' + (t.eta.predictedArrival || '—') + '</span></div>' +
    '<div class="mdp-row"><span class="l">Last updated</span><span class="v">' + t.live.lastUpdatedMinsAgo + ' min ago</span></div>' +
    '<a href="tracking.html?train=' + t.number + '" class="btn btn-primary btn-sm">Open Live Tracking</a>';

  emptyEl.classList.add('hidden');
  contentEl.classList.remove('hidden');
}

/* ==========================================
   STATION SEARCH
   ========================================== */
var searchInput = document.getElementById('map-search-input');
var suggestionsBox = document.getElementById('map-suggestions');
var allStationNames = Object.keys(STATION_COORDS).sort();

function showSuggestions(query){
  var q = query.trim().toLowerCase();
  if(!q){ suggestionsBox.classList.add('hidden'); suggestionsBox.innerHTML=''; return; }

  var matches = allStationNames.filter(function(n){ return n.toLowerCase().indexOf(q) !== -1; }).slice(0, 8);
  if(!matches.length){
    suggestionsBox.innerHTML = '<div class="map-suggestion-empty">No station matches "' + query + '"</div>';
    suggestionsBox.classList.remove('hidden');
    return;
  }
  suggestionsBox.innerHTML = matches.map(function(n){
    return '<button type="button" class="map-suggestion-item" data-name="' + n + '">' +
      '<svg class="icon" viewBox="0 0 24 24" style="width:14px;height:14px;"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>' + n +
    '</button>';
  }).join('');
  suggestionsBox.classList.remove('hidden');

  suggestionsBox.querySelectorAll('.map-suggestion-item').forEach(function(btn){
    btn.addEventListener('click', function(){ goToStation(btn.getAttribute('data-name')); });
  });
}

function goToStation(name){
  var coord = STATION_COORDS[name];
  if(!coord) return;
  railMap.flyTo(coord, 11, { duration: 0.9 });
  var marker = stationMarkers[name];
  if(marker) marker.openPopup();
  searchInput.value = name;
  suggestionsBox.classList.add('hidden');
  showToast('Showing ' + name);
}

searchInput.addEventListener('input', function(){ showSuggestions(searchInput.value); });
searchInput.addEventListener('keydown', function(e){
  if(e.key === 'Enter'){
    var first = suggestionsBox.querySelector('.map-suggestion-item');
    if(first) goToStation(first.getAttribute('data-name'));
  }
});
document.addEventListener('click', function(e){
  if(!e.target.closest('.map-toolbar-row')) suggestionsBox.classList.add('hidden');
});

/* ==========================================
   RESET VIEW
   ========================================== */
document.getElementById('map-reset-btn').addEventListener('click', function(){
  railMap.setView([22.9734, 78.6569], 5);
  showToast('Showing the full network');
});
