/* ==========================================================
   SEARCH TRAIN PAGE JAVASCRIPT (search.html)
   ========================================================== */

var RECENT_KEY = 'gatisense_recent_searches';

// ==========================================
// RECENT SEARCHES (stored locally for this prototype)
// ==========================================
function getRecentSearches(){
  try{ return JSON.parse(localStorage.getItem(RECENT_KEY)) || []; }
  catch(e){ return []; }
}
function addRecentSearch(train){
  var list = getRecentSearches().filter(function(t){ return t.number !== train.number; });
  list.unshift({ number: train.number, name: train.name });
  localStorage.setItem(RECENT_KEY, JSON.stringify(list.slice(0, 5)));
}
function renderRecentSearches(){
  var list = getRecentSearches();
  var wrap = document.getElementById('recent-searches');
  var target = document.getElementById('recent-list');
  if(!list.length){ wrap.classList.add('hidden'); return; }
  wrap.classList.remove('hidden');
  target.innerHTML = list.map(function(t){
    return '<button type="button" class="recent-chip" data-num="' + t.number + '">' + t.number + ' ' + t.name + '</button>';
  }).join('');
  target.querySelectorAll('.recent-chip').forEach(function(btn){
    btn.addEventListener('click', function(){ runSearch(btn.getAttribute('data-num')); });
  });
}

// ==========================================
// DISPLAY SEARCH RESULTS
// ==========================================
function renderResults(query, results){
  var listEl = document.getElementById('results-list');
  var countEl = document.getElementById('results-count');
  var emptyEl = document.getElementById('empty-state');

  if(!results.length){
    listEl.innerHTML = '';
    countEl.textContent = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');
  countEl.textContent = results.length + ' train' + (results.length === 1 ? '' : 's') + ' found';

  listEl.innerHTML = results.map(function(t){
    var status = delayStatusInfo(t.live.currentDelayMin);
    return (
      '<div class="train-result">' +
        '<div class="train-result-icon"><img src="assets/logo/gatisense-mark.png" alt="" class="tri-mark"></div>' +
        '<div class="train-result-info">' +
          '<div class="name">' + t.number + ' ' + t.name + '</div>' +
          '<div class="route">' + t.source + ' → ' + t.destination + ' <span class="badge ' + status.cls + '">' + status.label + '</span></div>' +
        '</div>' +
        '<div class="train-result-times">' +
          '<div><div class="t-label">Scheduled arrival</div><div class="t-value">' + t.eta.scheduledArrival + '</div></div>' +
          '<div><div class="t-label">Predicted arrival</div><div class="t-value" style="color:' + (t.live.currentDelayMin > 0 ? 'var(--amber)' : 'var(--ink)') + ';">' + t.eta.predictedArrival + '</div></div>' +
        '</div>' +
        '<a href="tracking.html?train=' + t.number + '" class="btn btn-outline btn-sm" data-num="' + t.number + '">View Train</a>' +
        '<a href="eta.html?train=' + t.number + '" class="btn btn-primary btn-sm" data-num="' + t.number + '">View ETA</a>' +
      '</div>'
    );
  }).join('');

  // Record whichever result the passenger actually opens.
  listEl.querySelectorAll('[data-num]').forEach(function(el){
    el.addEventListener('click', function(){
      var train = getTrain(el.getAttribute('data-num'));
      if(train) addRecentSearch(train);
    });
  });
}

function runSearch(query){
  document.getElementById('search-input').value = query;
  var results = searchTrains(query);
  renderResults(query, results);
}

// ==========================================
// INIT
// ==========================================
document.getElementById('search-form').addEventListener('submit', function(e){
  e.preventDefault();
  runSearch(document.getElementById('search-input').value.trim());
});

(function init(){
  renderRecentSearches();
  var params = new URLSearchParams(window.location.search);
  var q = params.get('q') || '';
  runSearch(q); // empty query shows all trains, per the "4 trains found" prototype view
})();
