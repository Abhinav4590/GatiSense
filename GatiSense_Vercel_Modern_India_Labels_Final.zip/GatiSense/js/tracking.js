/* ==========================================================
   LIVE TRACKING PAGE JAVASCRIPT (tracking.html)
   ========================================================== */

var trackingMapInstance = null; // current Leaflet instance, so we can tear it down when switching trains
var currentBoardFilter = 'all';
var trainNumber;

// ==========================================
// ALL LIVE TRAINS BOARD
// A scannable, filterable strip of every train's current
// status — inspired by real running-status boards (IRCTC/NTES,
// Where is my Train) and the quick trip-switch lists in apps
// like Trainline/DB Navigator. Selecting a card loads that
// train into the detail view below, in place (no page reload).
// ==========================================
function boardBucket(t){
  if(t.status === 'cancelled' || t.status === 'rescheduled' || t.status === 'diverted') return 'issue';
  if(t.live.currentDelayMin === 0) return 'ontime';
  return 'delayed';
}

function renderLiveBoard(activeNumber){
  var stripEl = document.getElementById('live-board-strip');
  if(!stripEl) return;

  var trains = GATI_TRAINS.filter(function(t){
    return currentBoardFilter === 'all' || boardBucket(t) === currentBoardFilter;
  });

  if(!trains.length){
    stripEl.innerHTML = '<div class="live-board-empty">No trains match this filter right now.</div>';
    return;
  }

  stripEl.innerHTML = trains.map(function(t){
    var status = delayStatusInfo(t.live.currentDelayMin);
    var isIssue = t.status === 'cancelled' || t.status === 'rescheduled' || t.status === 'diverted';
    var badgeCls = isIssue ? 'badge-neutral' : status.cls;
    var badgeLabel = isIssue ? statusWordLabel(t.status) : status.label;
    var isActive = t.number === activeNumber;

    return (
      '<button type="button" class="live-board-card' + (isActive ? ' active' : '') + '" data-num="' + t.number + '">' +
        '<div class="lbc-top">' +
          '<span class="lbc-num">' + t.number + '</span>' +
          '<span class="badge ' + badgeCls + '">' + badgeLabel + '</span>' +
        '</div>' +
        '<div class="lbc-name">' + t.name + '</div>' +
        '<div class="lbc-route">' + t.source + ' → ' + t.destination + '</div>' +
        '<div class="lbc-next">' + (t.live.nextStation && t.live.nextStation !== '—' ? ('Next: ' + t.live.nextStation + (t.live.nextStationEta ? (' · ' + t.live.nextStationEta) : '')) : t.live.currentLocationText) + '</div>' +
      '</button>'
    );
  }).join('');

  stripEl.querySelectorAll('.live-board-card').forEach(function(card){
    card.addEventListener('click', function(){
      loadTrain(card.getAttribute('data-num'));
    });
  });
}

function wireBoardFilters(){
  var pillsEl = document.getElementById('live-filter-pills');
  if(!pillsEl) return;
  pillsEl.querySelectorAll('.filter-pill').forEach(function(pill){
    pill.addEventListener('click', function(){
      pillsEl.querySelectorAll('.filter-pill').forEach(function(p){ p.classList.remove('active'); });
      pill.classList.add('active');
      currentBoardFilter = pill.getAttribute('data-filter');
      renderLiveBoard(trainNumber);
    });
  });
}

// ==========================================
// LOAD A TRAIN INTO THE DETAIL VIEW
// Updates the URL (without a page reload) and re-renders
// everything below the live board for the selected train.
// ==========================================
function loadTrain(number){
  trainNumber = number;
  var train = getTrain(number);
  var url = new URL(window.location.href);
  url.searchParams.set('train', number);
  window.history.pushState({}, '', url);

  // Clear out any status banner from a previous train.
  var oldBanner = document.querySelector('.status-banner');
  if(oldBanner) oldBanner.remove();

  if(!train){
    document.getElementById('tracking-content').classList.add('hidden');
    document.getElementById('tracking-not-found').classList.remove('hidden');
    renderLiveBoard(number);
    return;
  }

  document.getElementById('tracking-content').classList.remove('hidden');
  document.getElementById('tracking-not-found').classList.add('hidden');

  renderTrainHeader(train);
  renderStatusBanner(train);
  renderMap(train);
  renderTimeline(train);
  wireSaveButton(train);
  wireShareButton(train);
  renderLiveBoard(number);
}

// ==========================================
// DYNAMIC PROTOTYPE REFRESH
// Recalculates each selected train's ETA independently every 30s.
// No page reload and no history entry is created.
// ==========================================
function refreshCurrentTrain(){
  if(!trainNumber) return;
  var train = getTrain(trainNumber);
  if(!train) return;
  renderTrainHeader(train);
  renderMap(train);
  renderTimeline(train);
  renderLiveBoard(trainNumber);
}

// ==========================================
// INIT
// ==========================================
(function init(){
  var params = new URLSearchParams(window.location.search);
  wireBoardFilters();
  loadTrain(params.get('train') || '12951');
})();

window.addEventListener('popstate', function(){
  var params = new URLSearchParams(window.location.search);
  loadTrain(params.get('train') || '12951');
});

setInterval(refreshCurrentTrain, 30000);

// ==========================================
// STATUS BANNER — cancelled / rescheduled / diverted
// Only shown for a train that actually has one of these
// statuses; a normal running/on-time train shows nothing here.
// ==========================================
function renderStatusBanner(t){
  if(t.status !== 'cancelled' && t.status !== 'rescheduled' && t.status !== 'diverted') return;

  var banner = document.createElement('div');
  banner.className = 'status-banner ' + t.status;

  var iconPath = t.status === 'cancelled'
    ? '<path d="M6 6l12 12M18 6L6 18"/>'
    : '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>';

  var title = '', detail = '';
  if(t.status === 'cancelled'){
    title = 'Train Cancelled';
    detail = (t.statusDetail && t.statusDetail.note) || 'This service is cancelled.';
  } else if(t.status === 'rescheduled'){
    title = 'Rescheduled';
    var sd = t.statusDetail || {};
    detail = 'Original departure ' + sd.originalDeparture + ' → now departing ' + sd.updatedDeparture + '.';
  } else if(t.status === 'diverted'){
    title = 'Running on a diverted route';
    detail = (t.statusDetail && t.statusDetail.note) || 'This train is currently on an alternate route.';
  }

  banner.innerHTML =
    '<div class="sb-icon"><svg class="icon" viewBox="0 0 24 24">' + iconPath + '</svg></div>' +
    '<div><h4>' + title + '</h4><p>' + detail + '</p></div>';

  document.getElementById('tracking-content').insertBefore(banner, document.querySelector('.tracking-infobar'));
}

// ==========================================
// SAVE TRAIN (My Trains)
// Login is required for this personalization feature, in line
// with the project's login rule — basic tracking never
// requires it. The button node is cloned first so switching
// trains never stacks up duplicate click listeners.
// ==========================================
function wireSaveButton(t){
  var oldBtn = document.getElementById('t-save-btn');
  var btn = oldBtn.cloneNode(true);
  oldBtn.parentNode.replaceChild(btn, oldBtn);

  function refresh(){
    var saved = GatiSaved.isSaved(t.number);
    btn.textContent = saved ? 'Saved ✓' : 'Save Train';
    btn.classList.toggle('is-saved', saved);
  }

  btn.addEventListener('click', function(){
    if(!GatiAuth.isLoggedIn()){
      showToast('Log in to save trains to My Trains');
      setTimeout(function(){ window.location.href = 'login.html'; }, 700);
      return;
    }
    if(GatiSaved.isSaved(t.number)){
      GatiSaved.remove(t.number);
      showToast('Removed from My Trains');
    } else {
      GatiSaved.add(t.number);
      showToast('Saved to My Trains');
    }
    refresh();
  });

  refresh();
}

// ==========================================
// SHARE TRAIN STATUS
// Uses the browser Share API where available, otherwise
// copies a short status message to the clipboard. The button
// node is cloned first so switching trains never stacks up
// duplicate click listeners.
// ==========================================
function wireShareButton(t){
  var oldBtn = document.getElementById('t-share-btn');
  var btn = oldBtn.cloneNode(true);
  oldBtn.parentNode.replaceChild(btn, oldBtn);

  btn.addEventListener('click', function(){
    var message = 'GatiSense Train Status\n\n' + t.number + ' ' + t.name + '\n' +
      t.source + ' → ' + t.destination + '\n\n' +
      'Current delay: ' + (t.live.currentDelayMin > 0 ? ('+' + t.live.currentDelayMin + ' min') : 'On time') + '\n' +
      'Predicted arrival: ' + t.eta.predictedArrival;

    if(navigator.share){
      navigator.share({ title: 'GatiSense Train Status', text: message }).catch(function(){});
    } else if(navigator.clipboard){
      navigator.clipboard.writeText(message);
      showToast('Status copied — ready to paste and share');
    } else {
      showToast('Sharing isn\'t supported in this browser');
    }
  });
}

// ==========================================
// TRAIN HEADER + STATUS INFO BAR
// ==========================================
function renderTrainHeader(t){
  document.title = t.number + ' ' + t.name + ' — Live Tracking — GatiSense';
  document.getElementById('t-title').textContent = t.number + ' ' + t.name;
  document.getElementById('t-route').textContent = t.source + ' → ' + t.destination;

  var status = delayStatusInfo(t.live.currentDelayMin);
  var badge = document.getElementById('t-status-badge');
  badge.className = 'badge ' + status.cls;
  badge.textContent = t.live.currentDelayMin > 0 ? ('Running · ' + status.label) : 'On time';

  document.getElementById('t-location').textContent = t.live.currentLocationText;
  document.getElementById('t-delay').textContent = t.live.currentDelayMin > 0 ? ('+' + t.live.currentDelayMin + ' minutes') : 'On time';
  document.getElementById('t-next').textContent = t.live.nextStation + (t.live.nextStationEta ? (' · ' + t.live.nextStationEta) : '');
  document.getElementById('t-updated').textContent = t.live.lastUpdatedMinsAgo + ' min ago';

  var typeEl = document.getElementById('t-type');
  var daysEl = document.getElementById('t-days');
  var distEl = document.getElementById('t-distance');
  var schedEl = document.getElementById('t-scheduled-arrival');
  var predEl = document.getElementById('t-predicted-arrival');
  var confEl = document.getElementById('t-confidence');
  if(typeEl) typeEl.textContent = t.type || '—';
  if(daysEl) daysEl.textContent = t.runningDays || '—';
  if(distEl) distEl.textContent = t.distanceKm ? (t.distanceKm + ' km') : '—';
  if(schedEl) schedEl.textContent = t.eta && t.eta.scheduledArrival ? t.eta.scheduledArrival : '—';
  if(predEl) predEl.textContent = t.eta && t.eta.predictedArrival ? t.eta.predictedArrival : '—';
  if(confEl) confEl.textContent = t.eta && t.eta.confidencePct ? (t.eta.confidencePct + '%') : '—';
}

// ==========================================
// LIVE MAP (Indian Railway GIS + GatiSense)
// Shows the real route line, passed/upcoming station markers,
// and the train's current simulated position. Tears down any
// previous map instance first, since switching trains reuses
// the same #tracking-map container.
// ==========================================
function renderMap(t){
  if(trackingMapInstance){
    trackingMapInstance.remove();
    trackingMapInstance = null;
  }

  var map = L.map('tracking-map', { preferCanvas: true, scrollWheelZoom: true, zoomAnimation: true, fadeAnimation: true, zoomAnimationThreshold: 4, minZoom: 4, maxZoom: 15 });
  trackingMapInstance = map;

  var baseLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    attribution: '&copy; Esri, DeLorme, NAVTEQ',
    maxZoom: 19,
    updateWhenIdle: true,
    updateWhenZooming: false,
    keepBuffer: 1
  }).addTo(map);

  /* Use the same railway network and the same India boundary as the
     main Railway Map.  This prevents the tracking map from reverting
     to the old single-sub-layer railway GIS and ensures the black
     India outline is present here too. */
  addGatiIndiaMapLayers(map, {
    railwayOpacity: 0.95,
    boundaryWeight: 1.0
  });

  L.control.layers(
    { 'Map': baseLayer },
    {},
    { collapsed: true }
  ).addTo(map);

  var points = [];

  /* Medium-zoom station labels keep the live route readable without
     changing the existing route/marker rendering. */
  var stationLabelPane = map.createPane('gatiStationLabelPane');
  stationLabelPane.style.zIndex = 610;
  stationLabelPane.style.pointerEvents = 'none';
  var stationLabelMarkers = {};

  function addStationLabel(name, coord){
    if(!name || !coord || stationLabelMarkers[name]) return;
    var safeName = String(name).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    stationLabelMarkers[name] = L.marker(coord, {
      icon: L.divIcon({
        className: 'gati-station-label',
        html: '<span>' + safeName + '</span>',
        iconSize: null,
        iconAnchor: [0, 0]
      }),
      interactive: false,
      keyboard: false,
      pane: 'gatiStationLabelPane'
    });
  }

  function syncTrackingStationLabels(){
    var show = map.getZoom() >= 6;
    Object.keys(stationLabelMarkers).forEach(function(name){
      var marker = stationLabelMarkers[name];
      if(show){
        if(!map.hasLayer(marker)) marker.addTo(map);
      } else if(map.hasLayer(marker)){
        map.removeLayer(marker);
      }
    });
  }

  map.on('zoomend', syncTrackingStationLabels);

  /* ----------------------------------------------------------
     UNIFIED LIVE-ROUTE MARKERS
     Every train now uses the same station language:
       passed   = solid green check
       next     = amber focus ring + center dot
       upcoming = white/navy outlined dot
     The current train is always a small status-colored train icon.
     This is deliberately identical for full-stop and lightweight trains.
     ---------------------------------------------------------- */
  var routeStops = [];

  if(t.stops && t.stops.length){
    routeStops = t.stops.map(function(stop){
      var coord = STATION_COORDS[stop.name];
      if(!coord) return null;
      var state = stop.state || 'upcoming';
      if(stop.name === t.live.nextStation) state = 'next-marker';
      else if(state === 'departed') state = 'departed';
      else state = 'upcoming';
      return { name: stop.name, coord: coord, state: state };
    }).filter(Boolean);
  } else {
    routeStops = getRoutePoints(t).map(function(p){
      return { name: p.name, coord: p.coord, state: 'upcoming' };
    });

    /* Infer marker state for trains that do not have a full stop schedule.
       Everything before the next station is crossed; the next station gets
       the focused marker; everything after it remains upcoming. */
    var nextIndex = -1;
    routeStops.forEach(function(stop, i){
      if(stop.name === t.live.nextStation && nextIndex === -1) nextIndex = i;
    });
    if(nextIndex >= 0){
      routeStops.forEach(function(stop, i){
        stop.state = i < nextIndex ? 'departed' : (i === nextIndex ? 'next-marker' : 'upcoming');
      });
    } else if(routeStops.length){
      routeStops[0].state = 'departed';
    }
  }

  function stationMarkerIcon(state){
    var html;
    if(state === 'departed'){
      html = '<div class="gati-route-station passed" aria-label="Crossed station"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 12.5l3.4 3.4 7.7-8"/></svg></div>';
    } else {
      // Next and upcoming stations intentionally share one visual marker.
      // The current train icon is the only live-position marker, while
      // crossed stations use the green check. This keeps the route legend
      // simple and avoids competing visual meanings.
      html = '<div class="gati-route-station upcoming" aria-label="Next or upcoming station"></div>';
    }
    return L.divIcon({
      className: 'gati-route-station-icon',
      html: html,
      iconSize: [22, 22],
      iconAnchor: [11, 11]
    });
  }

  routeStops.forEach(function(stop){
    points.push(stop.coord);
    addStationLabel(stop.name, stop.coord);
    var marker = L.marker(stop.coord, {
      icon: stationMarkerIcon(stop.state),
      keyboard: false,
      zIndexOffset: stop.state === 'next-marker' ? 120 : 80
    }).addTo(map);
    var popupState = stop.state === 'departed' ? 'Crossed' : (stop.state === 'next-marker' ? 'Next station' : 'Upcoming station');
    marker.bindPopup('<b>' + stop.name + '</b><br>' + popupState);
  });

  syncTrackingStationLabels();

  /* ----------------------------------------------------------
     ROUTE LEGEND — gives the same visual language context on every
     live-tracking map without relying on color alone.
     ---------------------------------------------------------- */
  var legend = L.control({ position: 'bottomleft' });
  legend.onAdd = function(){
    var div = L.DomUtil.create('div', 'gati-route-legend');
    div.innerHTML =
      '<div class="grl-title">Route markers</div>' +
      '<div class="grl-row"><span class="grl-symbol grl-passed"><svg viewBox="0 0 24 24"><path d="M6.5 12.5l3.4 3.4 7.7-8"/></svg></span><span>Crossed</span></div>' +
      '<div class="grl-row"><span class="grl-symbol grl-upcoming"></span><span>Next / upcoming station</span></div>' +
      '<div class="grl-row"><span class="grl-line grl-line-green"></span><span>On-time route</span></div>' +
      '<div class="grl-row"><span class="grl-line grl-line-brown"></span><span>Delayed route</span></div>' +
      '<div class="grl-row"><span class="grl-line grl-line-red"></span><span>Major-delay route</span></div>' +
      '<div class="grl-row"><span class="grl-train-sample"><svg viewBox="0 0 24 24"><rect x="5" y="3.5" width="14" height="14" rx="3"/><path d="M8 17.5l-1.5 3M16 17.5l1.5 3M8 8h8M9 12h.01M15 12h.01"/></svg></span><span>Current train</span></div>';
    L.DomEvent.disableClickPropagation(div);
    return div;
  };
  legend.addTo(map);

  // Route line: first draw the safe station-corridor fallback, then replace
  // it with geometry traced directly over the OSM-derived railway network.
  // This is the important difference from a straight station-to-station line:
  // the highlighted service follows real railway curves, junctions and bends.
  var lineStops = getTrainLinePoints(t).map(function(p){ return p.coord; });
  var routeBucket = t.live.currentDelayMin === 0 ? 'ontime' : (t.live.currentDelayMin <= 15 ? 'delayed' : 'major');
  var routeColor = routeBucket === 'ontime' ? '#16804B' : (routeBucket === 'delayed' ? '#8B5A3C' : '#C43A3A');
  var routeCasing = null;
  var routeLine = null;

  function drawTrainRoute(pointsForLine){
    if(!pointsForLine || pointsForLine.length < 2) return;
    if(routeCasing && map.hasLayer(routeCasing)) map.removeLayer(routeCasing);
    if(routeLine && map.hasLayer(routeLine)) map.removeLayer(routeLine);

    routeCasing = L.polyline(pointsForLine, {
      color: '#FFFFFF', weight: 8, opacity: 0.90, lineCap: 'round', lineJoin: 'round',
      interactive: false, className: 'gati-live-route-casing'
    }).addTo(map);
    routeLine = L.polyline(pointsForLine, {
      color: routeColor, weight: 4.5, opacity: 0.97, lineCap: 'round', lineJoin: 'round',
      className: 'gati-live-route'
    }).addTo(map);
  }

  drawTrainRoute(lineStops);
  lineStops.forEach(function(p){ points.push(p); });

  // Current live position — a small geographic train icon, not a ball/pulse.
  if(Array.isArray(t.live.currentPosition) && t.live.currentPosition.length === 2){
    var currentBucket = t.live.currentDelayMin === 0 ? 'ontime' : (t.live.currentDelayMin <= 15 ? 'delayed' : 'major');
    var currentColorClass = currentBucket === 'ontime' ? 'on-time' : (currentBucket === 'delayed' ? 'delayed' : 'major');
    var trainIcon = L.divIcon({
      className: 'gati-current-train-icon',
      html: '<div class="gati-current-train ' + currentColorClass + '" aria-label="Current train position"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3.5" width="14" height="14" rx="3"/><path d="M8 17.5l-1.5 3M16 17.5l1.5 3M8 8h8M9 12h.01M15 12h.01"/></svg></div>',
      iconSize: [30, 30],
      iconAnchor: [15, 15]
    });
    var currentMarker = L.marker(t.live.currentPosition, {
      icon: trainIcon,
      keyboard: false,
      zIndexOffset: 500,
      riseOnHover: true
    }).addTo(map);
    currentMarker.bindPopup('<b>' + t.number + ' ' + t.name + '</b><br>' + t.live.currentLocationText + '<br><span style="color:#5B6472">Current train position</span>').openPopup();
    points.push(t.live.currentPosition);
  }

  /*
     Replace the fallback corridor with actual railway-network geometry.
     The operation is fail-soft: if the public railway feature service is
     unavailable, the already-rendered corridor remains visible.
  */
  if(typeof getAccurateTrainRoute === 'function'){
    getAccurateTrainRoute(t).then(function(accurateRoute){
      if(!accurateRoute || accurateRoute.length < 2) return;
      drawTrainRoute(accurateRoute);
      if(trackingMapInstance !== map) return;
      accurateRoute.forEach(function(p){ points.push(p); });
      map.fitBounds(points, { padding: [30, 30] });
    });
  }

  if(points.length){
    map.fitBounds(points, { padding: [30, 30] });
  } else {
    map.setView([22.9734, 78.6569], 5); // fallback: center of India
  }

}

// ==========================================
// ROUTE TIMELINE
// ==========================================
function renderTimeline(t){
  var listEl = document.getElementById('timeline-list');

  if(!t.stops || !t.stops.length){
    var route = getRoutePoints(t);
    if(!route.length){
      listEl.innerHTML = '<p style="font-size:13.5px;color:var(--ink-soft);">Route details are unavailable for this train.</p>';
      return;
    }
    listEl.innerHTML = route.map(function(point, i){
      var isNext = point.name === t.live.nextStation;
      var stateLabel = i === 0 ? 'Origin' : (i === route.length - 1 ? 'Destination' : (isNext ? 'Next station' : 'Route checkpoint'));
      var dotClass = i === 0 ? 'departed' : (isNext ? 'next' : '');
      return '<div class="tl-row"><div class="tl-dot-col"><div class="tl-dot ' + dotClass + '"></div><div class="tl-line"></div></div><div class="tl-info"><div><div class="name">' + point.name + '</div><div class="state-label">' + stateLabel + '</div></div></div></div>';
    }).join('');
    return;
  }

  listEl.innerHTML = t.stops.map(function(stop){
    var dotClass = stop.state === 'departed' ? 'departed' : (stop.state === 'next-marker' ? 'next' : '');
    var stateLabel = stop.state === 'departed' ? '✓ Departed' : '○ Upcoming';
    var isCurrentNext = stop.name === t.live.nextStation;
    if(isCurrentNext){ dotClass = 'next'; stateLabel = '● Next Station'; }

    var timesHtml = '';
    if(stop.schedArr){
      timesHtml = '<div class="tl-times">Scheduled<b>' + stop.schedArr + '</b></div>';
    } else if(stop.schedDep){
      timesHtml = '<div class="tl-times">Scheduled departure<b>' + stop.schedDep + '</b></div>';
    }

    return (
      '<div class="tl-row">' +
        '<div class="tl-dot-col"><div class="tl-dot ' + dotClass + '"></div><div class="tl-line"></div></div>' +
        '<div class="tl-info">' +
          '<div><div class="name">' + stop.name + '</div><div class="state-label">' + stateLabel + '</div></div>' +
          timesHtml +
        '</div>' +
      '</div>'
    );
  }).join('');
}
