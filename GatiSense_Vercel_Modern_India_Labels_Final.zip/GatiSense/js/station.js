/* ==========================================================
   LIVE STATION PAGE JAVASCRIPT (station.html)
   ========================================================== */

function escapeHtml(value){
  return String(value == null ? '' : value)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function stationKeyFromRecord(station){
  return stationText(station.code || station.name);
}

function findStationArrivalsForRecord(station){
  // Exact station identity only. The previous name/code/city merge used
  // substring matching, which could turn a city into a broad route match.
  // Live Station now uses the exact station name shown in Live Tracking.
  return getStationArrivals(station.name || station.code || '');
}

function renderStationCard(station){
  var arrivals = findStationArrivalsForRecord(station);
  var state = station.state || 'Indian Railways';
  var meta = [station.code ? station.code : 'Station', station.city || '', state].filter(Boolean).join(' · ');

  return '<article class="station-directory-card" data-station-code="' + escapeHtml(station.code) + '">' +
    '<div class="station-directory-main">' +
      '<div class="station-directory-pin">⌖</div>' +
      '<div>' +
        '<h3>' + escapeHtml(station.name) + '</h3>' +
        '<p>' + escapeHtml(meta) + '</p>' +
        (station.address ? '<div class="station-directory-address">' + escapeHtml(station.address) + '</div>' : '') +
      '</div>' +
    '</div>' +
    '<div class="station-directory-actions">' +
      '<span class="station-directory-status">' + (arrivals.length ? arrivals.length + ' modeled train' + (arrivals.length === 1 ? '' : 's') + ' in route data' : 'Station found') + '</span>' +
      '<button type="button" class="btn btn-outline btn-sm station-view-arrivals">View arrivals</button>' +
    '</div>' +
    '<div class="station-inline-arrivals hidden"></div>' +
  '</article>';
}

function renderArrivals(station, arrivals, target){
  if(!arrivals.length){
    target.innerHTML = '<div class="station-no-arrivals"><strong>No prototype arrival data for this station yet.</strong><span>The station is in the all-India directory, but none of the trains in the current GatiSense route catalog includes this exact station in its Live Tracking route.</span></div>';
    return;
  }

  target.innerHTML =
    '<div class="station-result-sub">Route-verified trains from the Live Tracking route data</div>' +
    '<div class="station-result-note">Times are shown only where this prototype contains a station-specific schedule. Route checkpoints are not assigned invented arrival times.</div>' +
    arrivals.map(function(a){
      var status = delayStatusInfo(a.delayMin);
      var badgeClass = 'badge-neutral';
      var badgeLabel = a.routeMatchKind || status.label;
      return '<div class="arrival-row compact">' +
        '<div class="name">' + escapeHtml(a.number) + ' <span class="num">' + escapeHtml(a.name) + '</span></div>' +
        '<span class="badge ' + badgeClass + '">' + escapeHtml(badgeLabel) + '</span>' +
        '<div class="arrival-times">' +
          '<div><div class="l">Scheduled</div><div class="v">' + escapeHtml(a.scheduled) + '</div></div>' +
          '<div><div class="l">Predicted</div><div class="v">' + escapeHtml(a.predicted) + '</div></div>' +
        '</div>' +
        '<a href="tracking.html?train=' + encodeURIComponent(a.number) + '" class="btn btn-outline btn-sm">Track</a>' +
      '</div>';
    }).join('');
}

function attachStationCardHandlers(){
  document.querySelectorAll('.station-view-arrivals').forEach(function(btn){
    btn.addEventListener('click', function(){
      var card = btn.closest('.station-directory-card');
      if(!card) return;
      var code = card.getAttribute('data-station-code') || '';
      var station = GATI_STATION_DIRECTORY.filter(function(s){ return String(s.code) === String(code); })[0];
      if(!station) return;
      var box = card.querySelector('.station-inline-arrivals');
      var open = !box.classList.contains('hidden');
      if(open){ box.classList.add('hidden'); btn.textContent = 'View arrivals'; return; }
      box.classList.remove('hidden');
      btn.textContent = 'Hide arrivals';
      renderArrivals(station, findStationArrivalsForRecord(station), box);
    });
  });
}

function renderStation(query){
  var resultsEl = document.getElementById('station-results');
  var emptyEl = document.getElementById('station-empty');
  var countEl = document.getElementById('station-result-count');
  var q = (query || '').trim();

  if(!q){
    resultsEl.innerHTML = '';
    countEl.textContent = '';
    emptyEl.classList.remove('hidden');
    emptyEl.querySelector('h3').textContent = 'Search for a station or city';
    emptyEl.querySelector('p').textContent = 'Try a station name, station code, or a city such as Ayodhya, Mumbai or Delhi.';
    return;
  }

  var matches = stationSearch(q, 100);
  if(!matches.length){
    resultsEl.innerHTML = '';
    countEl.textContent = '';
    emptyEl.classList.remove('hidden');
    emptyEl.querySelector('h3').textContent = 'No station found';
    emptyEl.querySelector('p').textContent = 'Try the station name, station code, or city name. The directory covers stations across India.';
    return;
  }

  emptyEl.classList.add('hidden');
  countEl.textContent = matches.length + (matches.length === 100 ? '+ ' : ' ') + 'station' + (matches.length === 1 ? '' : 's') + ' found';
  resultsEl.innerHTML =
    '<div class="station-results-grid">' + matches.map(renderStationCard).join('') + '</div>';
  attachStationCardHandlers();
}

function initStationPage(){
  var form = document.getElementById('station-form');
  var input = document.getElementById('station-input');
  var empty = document.getElementById('station-empty');
  var status = document.getElementById('station-directory-status');

  form.addEventListener('submit', function(e){
    e.preventDefault();
    var q = input.value.trim();
    if(!GATI_STATION_DIRECTORY_READY){
      status.textContent = 'Loading the India-wide station directory…';
      loadStationDirectory().then(function(){
        status.textContent = GATI_STATION_DIRECTORY.length.toLocaleString('en-IN') + ' stations available';
        renderStation(q);
      });
    } else {
      renderStation(q);
    }
  });

  input.addEventListener('input', function(){
    var q = input.value.trim();
    if(q.length >= 2 && GATI_STATION_DIRECTORY_READY) renderStation(q);
    if(q.length < 2){
      document.getElementById('station-results').innerHTML = '';
      document.getElementById('station-result-count').textContent = '';
      empty.classList.remove('hidden');
    }
  });

  loadStationDirectory().then(function(){
    status.textContent = GATI_STATION_DIRECTORY.length.toLocaleString('en-IN') + ' stations available';
  });
}

document.addEventListener('DOMContentLoaded', initStationPage);
