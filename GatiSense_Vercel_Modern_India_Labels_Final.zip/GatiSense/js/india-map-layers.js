/* ==========================================================
   SHARED INDIA MAP LAYERS
   Used by every Leaflet map in GatiSense.

   Railway rendering:
   - OpenRailwayMap standard is retained for its orange railway artwork.
   - Its raster tiles cover many countries, so GatiSense uses a custom
     canvas tile layer that clips the raster pixels to India's boundary.
   - This keeps the familiar OpenRailwayMap orange railway network inside
     India while preventing railway lines from neighboring countries from
     appearing on the GatiSense map.
   - The existing Indian railway GIS network remains underneath it.
   ========================================================== */

function addGatiIndiaMapLayers(map, options){
  options = options || {};

  if(!window.L || !map) return { railway: null, gisRailway: null, osmRailway: null, placeLabels: null, boundary: null };

  /* ==========================================================
     OPENRAILWAYMAP — INDIA-CLIPPED RASTER RAILWAY ARTWORK
     ==========================================================
     OpenRailwayMap's standard layer is a raster PNG layer. It contains
     railway lines for every country covered by the tile, so a normal
     L.tileLayer cannot know which pixels belong to India.

     We draw each tile onto a canvas and clip that canvas to the Indian
     boundary before the tile is displayed. This is a true geographic
     clip: panning/zooming does not move the mask independently of India.
  */
  var railwayPane = map.createPane('gatiOSMRailwayPane');
  railwayPane.style.zIndex = 320;
  railwayPane.style.pointerEvents = 'none';

  var railway = null;
  var railwayClipReady = false;

  /* Cache projected boundary rings by zoom level. */
  var projectedClipCache = {};
  var clipPolygons = null;

  function projectLonLat(lon, lat, z){
    var maxLat = 85.0511287798;
    lat = Math.max(-maxLat, Math.min(maxLat, lat));
    var scale = 256 * Math.pow(2, z);
    var rad = lat * Math.PI / 180;
    var sin = Math.sin(rad);
    return [
      (lon + 180) / 360 * scale,
      (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * scale
    ];
  }

  function prepareProjectedClip(z){
    if(projectedClipCache[z]) return projectedClipCache[z];

    var projected = [];
    if(!clipPolygons) return projected;

    clipPolygons.forEach(function(poly){
      var rings = poly.map(function(ring){
        return ring.map(function(point){
          return projectLonLat(point[0], point[1], z);
        });
      });
      projected.push(rings);
    });

    projectedClipCache[z] = projected;
    return projected;
  }

  function tileCanvasUrl(coords){
    return 'https://tiles.openrailwaymap.org/standard/' + coords.z + '/' + coords.x + '/' + coords.y + '.png';
  }

  function makeClippedRailwayLayer(){
    if(!railwayClipReady || !clipPolygons) return null;

    var ClippedRailwayLayer = L.GridLayer.extend({
      options: {
        tileSize: 256,
        opacity: options.railwayOpacity == null ? 0.95 : options.railwayOpacity,
        updateWhenIdle: false,
        updateWhenZooming: true,
        keepBuffer: 3,
        noWrap: true,
        minZoom: 2,
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors &middot; OpenRailwayMap'
      },

      createTile: function(coords, done){
        var tile = document.createElement('canvas');
        tile.width = 256;
        tile.height = 256;
        tile.className = 'leaflet-tile';

        var ctx = tile.getContext('2d');
        var img = new Image();
        img.crossOrigin = 'anonymous';

        var finished = false;
        function finish(err){
          if(finished) return;
          finished = true;
          done(err || null, tile);
        }

        img.onload = function(){
          try{
            var ringsAtZoom = prepareProjectedClip(coords.z);
            var tileLeft = coords.x * 256;
            var tileTop = coords.y * 256;

            ctx.save();
            ctx.beginPath();

            /*
             * evenodd makes every GeoJSON outer ring an inside region and
             * naturally cuts out holes/ring islands. Drawing all rings in
             * the same path also handles India's multipart geometry.
             */
            ringsAtZoom.forEach(function(poly){
              poly.forEach(function(ring){
                if(!ring.length) return;
                ctx.moveTo(ring[0][0] - tileLeft, ring[0][1] - tileTop);
                for(var i = 1; i < ring.length; i++){
                  ctx.lineTo(ring[i][0] - tileLeft, ring[i][1] - tileTop);
                }
                ctx.closePath();
              });
            });

            try{
              ctx.clip('evenodd');
            }catch(e){
              /* Older engines: GeoJSON ring winding still gives the
                 conventional outer/inner result with the default rule. */
              ctx.clip();
            }

            ctx.drawImage(img, 0, 0, 256, 256);
            ctx.restore();
            finish(null);
          }catch(err){
            console.warn('GatiSense clipped railway tile:', err);
            finish(err);
          }
        };

        img.onerror = function(){
          /* Do not fall back to an unclipped tile: that would reintroduce
             foreign-country railway lines, which this layer is designed to
             prevent. */
          finish(new Error('OpenRailwayMap tile failed to load'));
        };

        img.src = tileCanvasUrl(coords);
        return tile;
      }
    });

    return new ClippedRailwayLayer({
      pane: 'gatiOSMRailwayPane'
    }).addTo(map);
  }

  /* ==========================================================
     INDIA-ONLY MODERN PLACE LABELS
     ==========================================================
     The old raster label layer used Esri's World Boundaries and Places
     tiles. Raster text cannot be restyled with CSS, which is why changing
     the font had no visible effect.

     GatiSense now renders the important Indian state/city labels as HTML
     Leaflet markers. This gives us real CSS typography while leaving the
     base map, black India boundary, OpenRailwayMap artwork and GatiSense
     train routes completely untouched.
  */
  var labelsPane = map.createPane('gatiPlaceLabelsPane');
  labelsPane.style.zIndex = 560;
  labelsPane.style.pointerEvents = 'none';

  var placeLabels = L.layerGroup([], { pane: 'gatiPlaceLabelsPane' }).addTo(map);
  var placeLabelItems = [];

  /* State / UT labels. Coordinates are deliberately placed inside India. */
  var INDIA_STATE_LABELS = [
    ['JAMMU & KASHMIR',33.35,75.20], ['LADAKH',34.15,77.55],
    ['HIMACHAL PRADESH',31.55,77.15], ['PUNJAB',31.05,75.15],
    ['UTTARAKHAND',30.05,79.20], ['HARYANA',29.15,76.10],
    ['RAJASTHAN',26.85,73.85], ['UTTAR PRADESH',26.85,80.80],
    ['SIKKIM',27.55,88.50], ['ARUNACHAL PRADESH',28.10,94.20],
    ['ASSAM',26.25,92.85], ['NAGALAND',26.05,94.15],
    ['MEGHALAYA',25.55,91.30], ['BIHAR',25.75,85.35],
    ['MANIPUR',24.75,93.85], ['TRIPURA',23.75,91.55],
    ['MIZORAM',23.20,92.80], ['WEST BENGAL',23.20,87.80],
    ['JHARKHAND',23.55,85.30], ['GUJARAT',22.55,71.75],
    ['MADHYA PRADESH',23.45,78.35], ['CHHATTISGARH',21.30,82.00],
    ['ODISHA',20.55,84.45], ['MAHARASHTRA',19.35,76.10],
    ['TELANGANA',17.95,79.50], ['GOA',15.40,74.05],
    ['KARNATAKA',15.30,75.65], ['ANDHRA PRADESH',15.75,79.50],
    ['TAMIL NADU',11.10,78.45], ['KERALA',10.45,76.35],
    ['DELHI',28.62,77.18], ['CHANDIGARH',30.74,76.79],
    ['PUDUCHERRY',11.93,79.82], ['ANDAMAN & NICOBAR',11.80,92.75],
    ['LAKSHADWEEP',10.50,72.65]
  ];

  /* Major Indian cities. More are revealed as the user zooms in. */
  var INDIA_CITY_LABELS = [
    ['New Delhi',28.6139,77.2090,5], ['Mumbai',19.0760,72.8777,5],
    ['Kolkata',22.5726,88.3639,5], ['Chennai',13.0827,80.2707,5],
    ['Bengaluru',12.9716,77.5946,5], ['Hyderabad',17.3850,78.4867,5],
    ['Ahmedabad',23.0225,72.5714,5], ['Pune',18.5204,73.8567,5],
    ['Jaipur',26.9124,75.7873,5], ['Lucknow',26.8467,80.9462,5],
    ['Kanpur',26.4499,80.3319,5], ['Patna',25.5941,85.1376,5],
    ['Bhopal',23.2599,77.4126,5], ['Indore',22.7196,75.8577,5],
    ['Nagpur',21.1458,79.0882,5], ['Surat',21.1702,72.8311,5],
    ['Vadodara',22.3072,73.1812,5], ['Bhubaneswar',20.2961,85.8245,5],
    ['Visakhapatnam',17.6868,83.2185,5], ['Kochi',9.9312,76.2673,5],
    ['Coimbatore',11.0168,76.9558,5], ['Guwahati',26.1445,91.7362,5],
    ['Chandigarh',30.7333,76.7794,5], ['Dehradun',30.3165,78.0322,6],
    ['Amritsar',31.6340,74.8723,6], ['Jodhpur',26.2389,73.0243,6],
    ['Udaipur',24.5854,73.7125,6], ['Agra',27.1767,78.0081,6],
    ['Varanasi',25.3176,82.9739,6], ['Prayagraj',25.4358,81.8463,6],
    ['Meerut',28.9845,77.7064,6], ['Ranchi',23.3441,85.3096,6],
    ['Raipur',21.2514,81.6296,6], ['Jabalpur',23.1815,79.9864,6],
    ['Aurangabad',19.8762,75.3433,6], ['Nashik',19.9975,73.7898,6],
    ['Rajkot',22.3039,70.8022,6], ['Mysuru',12.2958,76.6394,6],
    ['Vijayawada',16.5062,80.6480,6], ['Madurai',9.9252,78.1198,6],
    ['Tiruchirappalli',10.7905,78.7047,6], ['Srinagar',34.0837,74.7973,6],
    ['Jammu',32.7266,74.8570,6], ['Shimla',31.1048,77.1734,6],
    ['Siliguri',26.7271,88.3953,6], ['Dhanbad',23.7957,86.4304,7],
    ['Gaya',24.7914,85.0002,7], ['Cuttack',20.4625,85.8830,7],
    ['Jamshedpur',22.8046,86.2029,7], ['Bikaner',28.0229,73.3119,7],
    ['Kota',25.2138,75.8648,7], ['Gwalior',26.2183,78.1828,7],
    ['Jhansi',25.4484,78.5685,7], ['Mathura',27.4924,77.6737,7],
    ['Bareilly',28.3670,79.4304,7], ['Gorakhpur',26.7606,83.3732,7],
    ['Haridwar',29.9457,78.1642,7], ['Panipat',29.3909,76.9635,7],
    ['Ludhiana',30.9010,75.8573,7], ['Jalandhar',31.3260,75.5762,7],
    ['Salem',11.6643,78.1460,7], ['Erode',11.3410,77.7172,7],
    ['Tirupati',13.6288,79.4192,7], ['Mangaluru',12.9141,74.8560,7],
    ['Hubballi',15.3647,75.1240,7], ['Belagavi',15.8497,74.4977,7],
    ['Warangal',17.9689,79.5941,7], ['Nellore',14.4426,79.9865,7]
  ];

  function addModernPlaceLabel(name, lat, lng, kind, minZoom){
    var className = kind === 'state' ? 'gati-map-state-label' :
                    kind === 'country' ? 'gati-map-country-label' : 'gati-map-city-label';
    var marker = L.marker([lat,lng], {
      icon: L.divIcon({
        className: className,
        html: '<span>' + name.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</span>',
        iconSize: null,
        iconAnchor: [0, 0]
      }),
      interactive: false,
      keyboard: false,
      pane: 'gatiPlaceLabelsPane'
    });
    placeLabelItems.push({ marker: marker, minZoom: minZoom || 5 });
  }

  INDIA_STATE_LABELS.forEach(function(item){
    addModernPlaceLabel(item[0], item[1], item[2], 'state', 5);
  });
  INDIA_CITY_LABELS.forEach(function(item){
    addModernPlaceLabel(item[0], item[1], item[2], 'city', item[3]);
  });

  /* India label is intentionally inside the country only. */
  addModernPlaceLabel('INDIA', 22.4, 79.2, 'country', 4);

  function syncModernPlaceLabels(){
    var z = map.getZoom();
    placeLabelItems.forEach(function(item){
      var visible = z >= item.minZoom;
      if(visible){
        if(!map.hasLayer(item.marker)) item.marker.addTo(placeLabels);
      }else if(map.hasLayer(item.marker)){
        placeLabels.removeLayer(item.marker);
      }
    });
  }
  map.on('zoomend', syncModernPlaceLabels);
  syncModernPlaceLabels();

  /* ==========================================================
     EXISTING INDIAN RAILWAY GIS — NETWORK ONLY
     ==========================================================
     Layer 1 is Railway Network (polyline). Layer 0, Railway Station,
     is deliberately NOT enabled because GatiSense supplies its own
     station directory/markers.
  */
  var gisRailway = null;
  if(window.L && L.esri){
    var gisRailwayPane = map.createPane('gatiExistingRailwayPane');
    gisRailwayPane.style.zIndex = 325;
    gisRailwayPane.style.pointerEvents = 'none';

    gisRailway = L.esri.dynamicMapLayer({
      url: 'https://livingatlas.esri.in/server1/rest/services/Railway/IN_Railway_Line/MapServer',
      opacity: options.existingRailwayOpacity == null ? 0.58 : options.existingRailwayOpacity,
      layers: [1],
      useCors: true,
      pane: 'gatiExistingRailwayPane',
      attribution: 'Railway network GIS: Esri India'
    }).addTo(map);
  }

  /* ==========================================================
     INDIA BOUNDARY + RAILWAY CLIP GEOMETRY
     ========================================================== */
  var boundaryPane = map.createPane('gatiIndiaBoundaryPane');
  boundaryPane.style.zIndex = 500;
  boundaryPane.style.pointerEvents = 'none';

  var boundary = null;
  fetch('assets/maps/india-boundary-overlay.geojson')
    .then(function(response){
      if(!response.ok) throw new Error('India boundary overlay failed to load');
      return response.json();
    })
    .then(function(data){
      boundary = L.geoJSON(data, {
        pane: 'gatiIndiaBoundaryPane',
        interactive: false,
        style: {
          color: '#111111',
          weight: options.boundaryWeight == null ? 1.0 : options.boundaryWeight,
          opacity: 1,
          lineCap: 'round',
          lineJoin: 'round',
          fill: false,
          fillOpacity: 0
        }
      }).addTo(map);
    })
    .catch(function(err){
      console.warn('GatiSense India boundary overlay:', err);
    });

  fetch('assets/maps/india-railway-clip.geojson')
    .then(function(response){
      if(!response.ok) throw new Error('India railway clip geometry failed to load');
      return response.json();
    })
    .then(function(data){
      var geometry = data && data.features && data.features[0] && data.features[0].geometry;
      if(!geometry) throw new Error('India railway clip geometry is missing');

      clipPolygons = geometry.type === 'MultiPolygon' ? geometry.coordinates : [geometry.coordinates];
      railwayClipReady = true;
      railway = makeClippedRailwayLayer();

      /* Use the exact same India geometry for the place-label clip. */
      labelClipPolygons = clipPolygons;
      labelClipReady = true;
      placeLabels = makeIndiaOnlyPlaceLabels();
    })
    .catch(function(err){
      console.warn('GatiSense clipped railway layer:', err);
    });

  return {
    railway: railway,
    osmRailway: railway,
    gisRailway: gisRailway,
    placeLabels: placeLabels,
    boundary: boundary
  };
}
