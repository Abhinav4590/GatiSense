# GatiSense Route Geometry & Station Accuracy Update

## What was changed

1. Route station markers now use railway-station coordinates for a larger set of major stations instead of city-centre coordinates.
2. The highlighted train route is drawn as straight geographic segments between ordered railway points. The previous Catmull-Rom spline is no longer used for the highlighted service route.
3. A white casing is drawn underneath the highlighted route so the selected service remains visually distinct from the orange OpenRailwayMap infrastructure layer.
4. Route colors are now:
   - Green: on-time
   - Brown: delayed
   - Red: major delay
5. Train 12951 has additional geometry-only corridor points (Borivali, Surat, Ratlam, Nagda, etc.) so its highlighted line follows the published corridor more closely while the timetable station markers remain tied to its actual scheduled stop list.

## Coordinate source

The station-point corrections were cross-checked against a public geocoded Indian railway station dataset containing station codes, names, and latitude/longitude coordinates:
https://github.com/prasenjit-27/Indian-Railway-Data

This is used as a coordinate reference in the prototype. It is not a live Indian Railways operational feed.

## Important geometry distinction

The highlighted GatiSense line is now a geographic polyline through real station/corridor points, not a mathematically smoothed curve. This prevents spline overshoot and makes the line visually angular/precise like a transit route diagram.

It is still not a track-level vector reconstruction of every rail switch and curve. Exact track-following would require a vector railway network and a route-matching step that selects the actual rail segments for each train service. The orange OpenRailwayMap infrastructure layer remains underneath to provide that detailed railway context.
