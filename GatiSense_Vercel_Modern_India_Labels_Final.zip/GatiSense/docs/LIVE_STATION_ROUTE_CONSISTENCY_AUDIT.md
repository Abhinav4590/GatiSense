# Live Station — Route/Arrival Consistency Audit

## Problem found

The Live Station page was not using one consistent source of truth.

It had a small hand-authored `GATI_STATION_ARRIVALS` board and then merged it with a second route-derived search. The route search also used substring matching against the station name, code and city. For example, searching a station record for **Kanpur Central** could also query the city **Kanpur**, which broadened the match and made the displayed arrival count disagree with the train's Live Tracking route.

## New rule

Live Station now derives station membership from the same route data used by **Live Tracking → Route & Schedule**:

1. A train is included only when the exact normalized station name appears in that train's configured route.
2. A full `stops` array is authoritative when a train has one.
3. Trains without a full timetable use the configured `TRAIN_ROUTE_WAYPOINTS` plus source and destination, matching the route/checkpoint list used by the prototype.
4. Station membership no longer depends on a station having a map coordinate.
5. City substring matching is removed.
6. Station-specific times are shown only when the prototype actually contains a station-specific schedule. No end-to-end ETA is reused as a fake intermediate station arrival.
7. Route checkpoints without a station-specific time are explicitly labelled **Route checkpoint** and display `—` for the time.

## Route corrections made during this audit

Several prototype route definitions were also checked against published train route/schedule references and corrected where the existing route introduced a known false station relationship:

- **12951** — corrected the Live Tracking schedule to the current Mumbai Central → New Delhi calls: Mumbai Central, Borivali, Surat, Vadodara, Ratlam, Nagda, Kota, New Delhi. The previous Sawai Madhopur, Bharatpur and Mathura entries were removed.
- **12437** — removed the incorrect Agra Cantt/Itarsi route points and aligned the corridor to Nagpur → Bhopal → Jhansi → Hazrat Nizamuddin.
- **12441** — removed the incorrect Jabalpur/Agra Cantt points and aligned the major corridor to Raipur → Nagpur → Bhopal → Jhansi → Gwalior → New Delhi.
- **12449** — removed the incorrect Pune/Jaipur relationship and added the relevant Madgaon → Ratnagiri/Panvel/Vasai Road → Surat → Vadodara → Ratlam → Kota → Delhi/Nizamuddin → Panipat → Chandigarh corridor points.
- **12555** — removed the incorrect Agra/Jaipur/Rewari relationship. Its configured prototype route now follows Lucknow → Kanpur Central → New Delhi → Rohtak → Bhiwani → Hisar.
- **12423** — removed the incorrect Gorakhpur relationship; the route now follows the configured Dibrugarh-side corridor through Guwahati/NJP/Katihar/Barauni/Prayagraj/Kanpur to New Delhi.
- **12626** — added the missing Gwalior and Bina corridor points.
- **12648** — removed the incorrect Secunderabad relationship.
- **12615** — added Bina, Gwalior, Mathura and Hazrat Nizamuddin to the configured major-station corridor.
- **12621** — added Itarsi, Jhansi, Gwalior and Hazrat Nizamuddin to the configured major-station corridor.
- **12627** — removed the incorrect Secunderabad relationship and aligned the major corridor through Bhusaval, Itarsi, Bhopal, Bina, Jhansi, Gwalior, Agra, Mathura and Hazrat Nizamuddin.
- **12708** — added the missing Jhansi, Gwalior and Mathura corridor points.
- **12815** — added Gaya and Prayagraj to the configured major corridor before Kanpur.

## Kanpur Central result

For the current 27-train GatiSense prototype catalogue, the route-consistent count is now **13 modeled train records**:

`12301, 12004, 12423, 12555, 12439, 12451, 12501, 12505, 12533, 12541, 12553, 12559, 12815`

This is a **prototype route count**, not a claim that Kanpur Central has only 13 real-world trains. A complete live station board would require a current authorized railway timetable/running-status feed.

## External validation used for spot checks

Published schedule references were checked for the most obvious discrepancies, including:

- 12951 Mumbai Central–New Delhi schedule
- 12301 Howrah–New Delhi Rajdhani schedule
- 12004 New Delhi–Lucknow Shatabdi schedule
- 12555 Gorakhdham Express schedule
- 12423 Dibrugarh–New Delhi Rajdhani schedule
- 12437 Secunderabad–Hazrat Nizamuddin Rajdhani schedule
- 12441 Bilaspur–New Delhi Rajdhani schedule
- 12449 Goa Sampark Kranti schedule
- 12648 Kongu Express schedule
- 12621 Tamil Nadu Express schedule
- 12627 Karnataka Express schedule
- 12815 Nandan Kanan Express schedule

The Indian Railways passenger enquiry site also confirms that train schedules are a separate timetable data source and that its schedule enquiry is intended for reserved trains in the PRS system.

## Important prototype limitation

The Live Station page should be described as a **route-consistency view of the GatiSense prototype catalogue**, not as a live all-India arrival board. The route membership is now internally consistent with Live Tracking, but the prototype still does not have an authorized live NTES/running-status feed for every train and station.
