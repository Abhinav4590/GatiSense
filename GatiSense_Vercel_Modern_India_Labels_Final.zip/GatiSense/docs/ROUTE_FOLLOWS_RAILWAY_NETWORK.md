# GatiSense — Railway-Aligned Train Routes

## Why the old route was wrong

The previous implementation connected station coordinates with ordinary geographic polylines. Even with additional junction waypoints, each segment was effectively a straight chord between two points. A spline was tested earlier, but a mathematical curve is not railway geometry either: it can bend across towns, fields, rivers, or open water that the train never uses.

## New behavior

GatiSense now treats the visible railway network as the route geometry source. For the selected train in Live Tracking, the application queries the OSM-derived railway polyline network already used by the map and traces a connected path between consecutive train-route stations. The highlighted red/green/brown service line is drawn on top of those real railway polylines.

The process is:

1. Take the ordered railway stations/corridor points for the train.
2. For each consecutive pair, request railway polylines inside a narrow geographic corridor.
3. Build a small graph from the returned railway line vertices and segments.
4. Connect nearby railway vertices so adjacent mapped track segments form a usable graph.
5. Find the lowest-cost connected railway path between the two stations.
6. Concatenate the legs to create the complete train route geometry.
7. Render that geometry in the GatiSense status color, with a thin white casing so it remains distinguishable from OpenRailwayMap's orange infrastructure artwork.

This produces a route that turns where the railway turns instead of drawing a straight line between cities.

## Fallback behavior

The route tracer is asynchronous and fail-soft. If the railway feature service is unavailable, times out, returns no usable path, or the map cannot connect the requested points, GatiSense keeps the existing station-corridor route instead of leaving the map blank or throwing an error.

The main Railway Map does not query the network for all 27 trains during initial page load. That would create unnecessary network traffic. Its overview routes remain lightweight, while clicking a train upgrades that selected route to the railway-aligned geometry. Live Tracking upgrades the selected train automatically.

## Data source

The network comes from the Esri India OSM Railway Network feature layer, which is a polyline feature layer. The existing GatiSense OpenRailwayMap layer remains visible for detailed railway infrastructure context. The highlighted route is a separate GatiSense visualization and therefore uses red/green/brown rather than OpenRailwayMap's orange.
